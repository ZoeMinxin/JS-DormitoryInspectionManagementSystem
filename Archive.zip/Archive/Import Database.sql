-- MySQL dump 10.17  Distrib 10.3.16-MariaDB, for Linux (x86_64)
--
-- Host: mz65.host.cs.st-andrews.ac.uk    Database: mz65_dissertation
-- ------------------------------------------------------
-- Server version	10.3.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `damage`
--

DROP TABLE IF EXISTS `damage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `damage` (
  `r_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `damage_place` varchar(255) COLLATE utf8_bin NOT NULL,
  `report_time` varchar(20) COLLATE utf8_bin NOT NULL,
  `report_id` varchar(10) COLLATE utf8_bin NOT NULL,
  `damage_info` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `finish_time` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `other_info` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`r_name`,`damage_place`,`report_time`,`report_id`),
  CONSTRAINT `damage_ibfk_1` FOREIGN KEY (`r_name`) REFERENCES `residence` (`r_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `damage`
--

LOCK TABLES `damage` WRITE;
/*!40000 ALTER TABLE `damage` DISABLE KEYS */;
INSERT INTO `damage` VALUES ('David Russell Apartments','Game Room 1','2019-07-24 16:46:14','111111','sofa is missing','finish','2019-07-28 13:51:40','sofa is on the way->need 2 weeks->workers not here'),('David Russell Apartments','K2','2019-08-08 05:30:09','96325','The micro wave machine doesn’t work.','in process',NULL,'Change a new one as soon as possible.'),('David Russell Apartments','K3','2019-07-23 12:30:59','11111','sink is blocked','finish','2019-07-23 13:15:14','change the tube'),('David Russell Apartments','K4','2019-07-26 15:23:40','201202','microwave is broken','finish','2019-07-26 15:31:43',NULL),('David Russell Apartments','Laundry Room','2019-07-26 15:29:34','201202','...','finish','2019-07-26 15:36:32',NULL),('David Russell Apartments','Laundry Room','2019-07-28 13:02:01','11111','the 2nd machine does not work','finish',NULL,'on the way'),('Powell Hall','A1','2019-07-28 14:14:12','11111','sink','finish','2019-07-28 14:15:03','going->going->finish'),('Powell Hall','A2','2019-07-28 14:17:37','11111','toilet is broken','finish','2019-08-08 05:32:52','It has been fixed now.'),('Powell Hall','Laundry Room','2019-08-08 05:48:18','523069','The washing machine doesn’t work.','unread',NULL,NULL),('Powell Hall','Study Room','2019-07-24 16:31:59','11111','desk missing','finish','2019-07-28 13:55:21','');
/*!40000 ALTER TABLE `damage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbox`
--

DROP TABLE IF EXISTS `inbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inbox` (
  `out_id` varchar(6) COLLATE utf8_bin NOT NULL,
  `in_id` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `subject` varchar(100) COLLATE utf8_bin NOT NULL,
  `content` varchar(255) COLLATE utf8_bin NOT NULL,
  `send_time` varchar(20) COLLATE utf8_bin NOT NULL,
  `status` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `reply` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `reply_time` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`out_id`,`subject`,`content`,`send_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbox`
--

LOCK TABLES `inbox` WRITE;
/*!40000 ALTER TABLE `inbox` DISABLE KEYS */;
INSERT INTO `inbox` VALUES ('111111','88888','David Russell Apartments  - K2  - objection to kitchen inspection result','Not here','2019-07-24 15:34:00','unread',NULL,NULL),('111111','12121','David Russell Apartments  - K2  - objection to kitchen inspection result','why?  it is clean','2019-07-28 16:48:17','unread',NULL,NULL),('111111','11111','David Russell Apartments  - K2  - request for a new inspection time','14:45','2019-07-26 10:33:54','read','ss','2019-07-27 16:16:05'),('111111','11111','David Russell Apartments  - K2  - request for a new inspection time','8-114.00ok?','2019-07-28 16:09:30','unread',NULL,NULL),('111111',NULL,'David Russell Apartments  - K2 - request for a new inspection time','7-30','2019-07-24 16:05:24','unread',NULL,NULL),('111111','12121','David Russell Apartments  - M2  - objection to room inspection result','EXO me?  How can I pass all separate objectives but FAIL my inspection eventually? I request you to give me 10 reasonable reasons to explain your unreliable work! ','2019-07-26 15:19:05','read','one is enough that your room is so dirty','2019-07-26 15:37:23'),('111111','11111','Report B39,40 in Powell','He did nothing before the kitchen inspection for a couple of months and we cannot contact him','2019-07-23 17:05:06','read','We will contact him on 23rd July','2019-07-23 17:20:17'),('111111','11111','Report B39,40 in Powell ','They smoke in the kitchen again','2019-07-24 11:19:48','read','we will talk','2019-07-27 15:42:32'),('111111',NULL,'Why the inspection time changed?','I noticed that the inspection time changed in the system, why it changed?','2019-07-24 11:37:04','unread',NULL,NULL),('111111',NULL,'where is my pot?','Hi, my port is missing after you checked my room','2019-07-28 15:45:20','unread',NULL,NULL),('111111','11111','？','？','2019-07-26 15:17:02','read','??????','2019-07-27 16:21:39'),('523069',NULL,'Dear sir or madam ','I am writing to consult when the damaged washing machine could be fixed.Best Josephine ','2019-08-08 05:52:45','unread',NULL,NULL),('999999',NULL,'test','here is a test','2019-08-05 21:08:23','unread',NULL,NULL);
/*!40000 ALTER TABLE `inbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inspection_k`
--

DROP TABLE IF EXISTS `inspection_k`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inspection_k` (
  `r_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `kit_no` varchar(255) COLLATE utf8_bin NOT NULL,
  `Staff_id` char(5) COLLATE utf8_bin NOT NULL,
  `est_timek` varchar(255) COLLATE utf8_bin NOT NULL,
  `check_staff` char(5) COLLATE utf8_bin DEFAULT NULL,
  `microwave` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `fridge` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `surface` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `cooker` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `sink_k` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `rubbish` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `wall_k` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `carpet_k` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `set_otherk` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `result_k` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `check_timek` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`r_name`,`kit_no`,`Staff_id`,`est_timek`),
  KEY `Staff_id` (`Staff_id`),
  CONSTRAINT `inspection_k_ibfk_1` FOREIGN KEY (`r_name`) REFERENCES `residence` (`r_name`),
  CONSTRAINT `inspection_k_ibfk_2` FOREIGN KEY (`r_name`, `kit_no`) REFERENCES `kitchen` (`r_name`, `kit_no`),
  CONSTRAINT `inspection_k_ibfk_3` FOREIGN KEY (`Staff_id`) REFERENCES `staff` (`Staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inspection_k`
--

LOCK TABLES `inspection_k` WRITE;
/*!40000 ALTER TABLE `inspection_k` DISABLE KEYS */;
INSERT INTO `inspection_k` VALUES ('David Russell Apartments','K2','11111','2019-07-08T11:00','88888','GOOD','GOOD','GOOD','GOOD','GOOD','CLEAR','GOOD','GOOD','','PASS','2019-07-14 11:42:47'),('David Russell Apartments','K2','11111','2019-07-25 12:45','11111','GOOD','GOOD','GOOD','GOOD','GOOD','CLEAR','GOOD','GOOD','','PASS','2019-07-19 12:42:12'),('David Russell Apartments','K2','11111','2019-07-30 13:50','12121','GOOD','GOOD','GOOD','GOOD','GOOD','CLEAR','GOOD','GOOD','','PASS','2019-07-26 15:24:49'),('David Russell Apartments','K2','11111','2019-07-31 12:00','11111','GOOD','GOOD','GOOD','GOOD','GOOD','CLEAR','GOOD','GOOD','','PASS','2019-08-03 14:39:27'),('David Russell Apartments ','K3 ','11111','2019-07-16T12:00','88888','GOOD','GOOD','GOOD','GOOD','GOOD','CLEAR','GOOD','GOOD','','PASS','2019-07-14 14:09:52'),('David Russell Apartments','K3','11111','2019-07-30 12:00','11111','GOOD','GOOD','GOOD','GOOD','GOOD','CLEAR','GOOD','GOOD','','PASS','2019-07-27 17:26:47'),('David Russell Apartments','K3','88888','2019-07-11T12:00','11111','GOOD','NEED MORE CLEANING','NEED MORE CLEANING','NEED MORE CLEANING','GOOD','PLEASE EMPTY ALL THE RUBBISH','GOOD','GOOD','need more cleaning','FAIL','2019-07-14 14:08:21'),('David Russell Apartments','K4','12345','2019-07-19T14:00','12345','GOOD','NEED MORE CLEANING','NEED MORE CLEANING','NEED MORE CLEANING','GOOD','CLEAR','GOOD','GOOD','','FAIL','2019-07-18 15:43:49'),('Powell Hall','A1','11111','2019-07-09T12:00','12345','GOOD','GOOD','GOOD','GOOD','NEED MORE CLEANING','CLEAR','GOOD','GOOD','','PASS','2019-07-18 15:42:12'),('Powell Hall','A1','11111','2019-07-30 12:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Powell Hall','B1','11111','2019-07-24 15:00','11111','GOOD','GOOD','GOOD','GOOD','GOOD','CLEAR','GOOD','GOOD','','PASS','2019-08-04 16:05:26'),('Powell Hall','B1','12191','2019-07-29 12:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `inspection_k` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inspection_r`
--

DROP TABLE IF EXISTS `inspection_r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inspection_r` (
  `r_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `room_no` varchar(255) COLLATE utf8_bin NOT NULL,
  `Staff_id` char(5) COLLATE utf8_bin NOT NULL,
  `est_timer` varchar(255) COLLATE utf8_bin NOT NULL,
  `check_staff` char(5) COLLATE utf8_bin DEFAULT NULL,
  `shower_room` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `sink_r` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `mirror_bed` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `mirror_wash` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `toilet` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `bin` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `safety_notice` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `poster` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `wall_r` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `carpet_r` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `skirting` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `set_otherr` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `result_r` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `check_timer` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`r_name`,`room_no`,`Staff_id`,`est_timer`),
  KEY `Staff_id` (`Staff_id`),
  CONSTRAINT `inspection_r_ibfk_1` FOREIGN KEY (`r_name`) REFERENCES `residence` (`r_name`),
  CONSTRAINT `inspection_r_ibfk_2` FOREIGN KEY (`r_name`, `room_no`) REFERENCES `room` (`r_name`, `room_no`),
  CONSTRAINT `inspection_r_ibfk_3` FOREIGN KEY (`Staff_id`) REFERENCES `staff` (`Staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inspection_r`
--

LOCK TABLES `inspection_r` WRITE;
/*!40000 ALTER TABLE `inspection_r` DISABLE KEYS */;
INSERT INTO `inspection_r` VALUES ('David Russell Apartments ','M2 ','11111','2019-07-25T13:13','11111','GOOD','GOOD','GOOD','GOOD','GOOD','CLEAR','EXIST','CLEAR','GOOD','GOOD','CLEAR','','PASS','2019-07-27 18:07:59'),('David Russell Apartments','M2','12345','2019-07-20T20:20','12345','GOOD','GOOD','GOOD','GOOD','GOOD','CLEAR','EXIST','CLEAR','GOOD','GOOD','CLEAR','','FAIL','2019-07-18 15:54:33'),('David Russell Apartments','M2','88888','2019-07-10T11:00','88888','GOOD','GOOD','GOOD','GOOD','GOOD','CLEAR','EXIST','CLEAR','GOOD','GOOD','CLEAR','','PASS','2019-07-14 14:26:31'),('David Russell Apartments','M3','11111','2019-07-31 14:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Powell Hall','A1','88888','2019-07-11T13:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Powell Hall','A2','11111','2019-07-30 12:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `inspection_r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kitchen`
--

DROP TABLE IF EXISTS `kitchen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kitchen` (
  `r_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `kit_no` varchar(255) COLLATE utf8_bin NOT NULL,
  `capacity` int(2) NOT NULL,
  PRIMARY KEY (`r_name`,`kit_no`),
  CONSTRAINT `kitchen_ibfk_1` FOREIGN KEY (`r_name`) REFERENCES `residence` (`r_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kitchen`
--

LOCK TABLES `kitchen` WRITE;
/*!40000 ALTER TABLE `kitchen` DISABLE KEYS */;
INSERT INTO `kitchen` VALUES ('David Russell Apartments','K2',1),('David Russell Apartments','K3',3),('David Russell Apartments','K4',4),('Powell Hall','A1',5),('Powell Hall','B1',5);
/*!40000 ALTER TABLE `kitchen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `occupied`
--

DROP TABLE IF EXISTS `occupied`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `occupied` (
  `r_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `room_no` varchar(255) COLLATE utf8_bin NOT NULL,
  `kit_no` varchar(255) COLLATE utf8_bin NOT NULL,
  `stu_id` char(6) COLLATE utf8_bin NOT NULL,
  `move_in_date` varchar(20) COLLATE utf8_bin NOT NULL,
  `move_out_date` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`r_name`,`room_no`,`kit_no`,`stu_id`,`move_in_date`),
  KEY `r_name` (`r_name`,`kit_no`),
  KEY `stu_id` (`stu_id`),
  CONSTRAINT `occupied_ibfk_1` FOREIGN KEY (`r_name`) REFERENCES `residence` (`r_name`),
  CONSTRAINT `occupied_ibfk_2` FOREIGN KEY (`r_name`, `room_no`) REFERENCES `room` (`r_name`, `room_no`),
  CONSTRAINT `occupied_ibfk_3` FOREIGN KEY (`r_name`, `kit_no`) REFERENCES `kitchen` (`r_name`, `kit_no`),
  CONSTRAINT `occupied_ibfk_4` FOREIGN KEY (`stu_id`) REFERENCES `student` (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `occupied`
--

LOCK TABLES `occupied` WRITE;
/*!40000 ALTER TABLE `occupied` DISABLE KEYS */;
INSERT INTO `occupied` VALUES ('David Russell Apartments','M2','K2','111111','2019-07-10','2019-07-19'),('David Russell Apartments','M2','K2','123213','2019-08-04',NULL),('David Russell Apartments','M2','K2','201202','2018-09-08',NULL),('David Russell Apartments','M2','K2','523069','2019-08-08','2019-08-12'),('David Russell Apartments','M3','K2','111111','2019-07-26',NULL),('David Russell Apartments','M4','K3','666666','2019-07-18','2019-07-25'),('Powell Hall','A2','A1','999999','2019-08-01',NULL);
/*!40000 ALTER TABLE `occupied` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `occupies`
--

DROP TABLE IF EXISTS `occupies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `occupies` (
  `r_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `room_no` varchar(255) COLLATE utf8_bin NOT NULL,
  `kit_no` varchar(255) COLLATE utf8_bin NOT NULL,
  `stu_id` char(6) COLLATE utf8_bin NOT NULL,
  `move_in_date` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`r_name`,`room_no`,`kit_no`,`stu_id`,`move_in_date`),
  KEY `r_name` (`r_name`,`kit_no`),
  KEY `stu_id` (`stu_id`),
  CONSTRAINT `occupies_ibfk_1` FOREIGN KEY (`r_name`) REFERENCES `residence` (`r_name`),
  CONSTRAINT `occupies_ibfk_2` FOREIGN KEY (`r_name`, `room_no`) REFERENCES `room` (`r_name`, `room_no`),
  CONSTRAINT `occupies_ibfk_3` FOREIGN KEY (`r_name`, `kit_no`) REFERENCES `kitchen` (`r_name`, `kit_no`),
  CONSTRAINT `occupies_ibfk_4` FOREIGN KEY (`stu_id`) REFERENCES `student` (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `occupies`
--

LOCK TABLES `occupies` WRITE;
/*!40000 ALTER TABLE `occupies` DISABLE KEYS */;
INSERT INTO `occupies` VALUES ('David Russell Apartments','M2','K2','123213','2019-08-04'),('David Russell Apartments','M2','K2','201202','2018-09-08'),('David Russell Apartments','M2','K2','523069','2019-08-08'),('David Russell Apartments','M3','K2','111111','2019-07-26'),('David Russell Apartments','M4','K3','666666','2019-07-18'),('Powell Hall','A2','A1','999999','2019-08-01');
/*!40000 ALTER TABLE `occupies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `residence`
--

DROP TABLE IF EXISTS `residence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `residence` (
  `r_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `address` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`r_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `residence`
--

LOCK TABLES `residence` WRITE;
/*!40000 ALTER TABLE `residence` DISABLE KEYS */;
INSERT INTO `residence` VALUES ('David Russell Apartments','KY16 9LY'),('Powell Hall','KY16 9XW');
/*!40000 ALTER TABLE `residence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `r_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `room_no` varchar(255) COLLATE utf8_bin NOT NULL,
  `capacity` int(2) NOT NULL,
  `room_type` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`r_name`,`room_no`),
  CONSTRAINT `room_ibfk_1` FOREIGN KEY (`r_name`) REFERENCES `residence` (`r_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES ('David Russell Apartments','M2',1,'single room'),('David Russell Apartments','M3',3,'family'),('David Russell Apartments','M4',4,'flat'),('Powell Hall','A1',1,'single room'),('Powell Hall','A2',2,'double room');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `Staff_id` char(5) COLLATE utf8_bin NOT NULL,
  `Staff_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `Staff_email` varchar(255) COLLATE utf8_bin NOT NULL,
  `Staff_pwd` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`Staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES ('11111','Minxin Zhang','mz65@st-andrews.ac.uk','123456'),('12121','Jason','jason12@gmail.com','123'),('12191','chining','zcn1219@vip.qq.com','Zhangcn.1219'),('12312','1','18630526196@163.COM','1'),('12345','Ruth','rr11@gmail.com','12345'),('77777','Jack','jc44@st-andrews.ac.uk','123'),('88888','John Honey','jh@st-andrews.ac.uk','123456'),('96325','Josephine ','josephine.yang228@gmail.com','ydn523069');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `stu_id` char(6) COLLATE utf8_bin NOT NULL,
  `stu_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `stu_email` varchar(255) COLLATE utf8_bin NOT NULL,
  `stu_pwd` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('111111','Stephen','ss22@gmail.com','123'),('123213','Ли Юйсянь','178814328@qq.com','19960719qwer,./'),('123456','someone','123@gmail.com','123'),('127111','mgg','1@qq.com','1'),('201202','Rita','hx24@st-andrews.ac.uk','201202'),('523069','Josephine ','josephine.yang228@gmail.com','ydn523069'),('666666','Nana','nanah@gmail.com','123456'),('999999','Demo','demo@gmail.com','999999');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'mz65_dissertation'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-13 15:35:10
