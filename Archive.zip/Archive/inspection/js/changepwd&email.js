function oandn() {  //check original and new password
    var pw3 = document.getElementById("pw3").value;
    var pw1 = document.getElementById("pw1").value;
    if(pw3 == pw1) {
    document.getElementById("tipchange").innerHTML="<center><font color='red'><br><b>New password cannot be the same as original one!</b></font></center></br>";
    document.getElementById("submit").disabled = false;
    }
    else {
    document.getElementById("tipchange").innerHTML="<font></font>";
    document.getElementById("submit").disabled = true;
    }
}

function validate() {  //check confirm password
    var pw1 = document.getElementById("pw1").value;
    var pw2 = document.getElementById("pw2").value;
    if(pw1 == pw2) {
    document.getElementById("tip").innerHTML="<font></font>";
    document.getElementById("submit").disabled = false;
    }
    else {
    document.getElementById("tip").innerHTML="<center><font color='red'><br><b>Passwords don't match.</b></font></center></br>";
    document.getElementById("submit").disabled = true;
    }
}

function eoandn() {  //check original and new email
    var em3 = document.getElementById("em3").value;
    var em1 = document.getElementById("em1").value;
    if(em3 == em1) {
    document.getElementById("etipchange").innerHTML="<center><font color='red'><br><b>New Email Address cannot be the same as original one!</b></font></center></br>";
    document.getElementById("submit").disabled = false;
    }
    else {
    document.getElementById("etipchange").innerHTML="<font></font>";
    document.getElementById("submit").disabled = true;
    }
}

/*function evalidate() {
    var em1 = document.getElementById("em1").value;
    var em2 = document.getElementById("em2").value;
    if(em1 == em2) {
    document.getElementById("etip").innerHTML="<font></font>";
    document.getElementById("submit").disabled = false;
    }
    else {
    document.getElementById("etip").innerHTML="<center><font color='red'><br><b>Email Address doesn't match.</b></font></center></br>";
    document.getElementById("submit").disabled = true;
    }
}*/

//email does not need to input twice