  //option selecte true
  function Get_Selected_Id(kit){
    var pro = document.getElementById(kit);
    var Selected_Id = pro.options[pro.selectedIndex].id;
    return Selected_Id;   //back selected true
   }
   //2
   function Get_Next_Kit(This_Kit_ID,Action){
    var Selected_Id = Get_Selected_Id(This_Kit_ID); //Selected_Id from 1
    if(Action=='Get_kit')       
     Add_kit(Selected_Id);
    else if(Action=='Get_room')
     Add_room(Selected_Id);
   }
  
   var Kit_dict = {
    "David Russell Apartments":{
        "K2":["M2","M3"],
        "K3":["M4"]
        },
    "Powell Hall":{
        "A1":["A1","A2"]
        }
   };
   
   function Add_kit(residence_Selected_Id){
    $("#kit").empty();
    $("#kit").append("<option>Choose Kitchen</option>");
    $("#room").empty();
    $("#room").append("<option>Choose Room</option>");
   
    var residence_dict = Kit_dict[residence_Selected_Id]; 
    for(kit in residence_dict){  
     
     var text = "<option"+" id='"+kit+"'>"+kit+"</option>";
     $("#kit").append(text);
     //console.log(text); 
    }
   }
  
   function Add_room(kit_Selected_Id){
    $("#room").empty();
    $("#room").append("<option>Choose Room</option>");
   
    var residence_Selected_ID = Get_Selected_Id("residence"); 
    var room_list = Kit_dict[residence_Selected_ID][kit_Selected_Id]; 
    for(index in room_list){
    
     var text = "<option"+" id=\'"+room_list[index]+"\'>"+room_list[index]+"</option>";
     $("#room").append(text);
     //console.log(text); 
    }
   }