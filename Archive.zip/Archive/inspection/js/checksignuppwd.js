function validate() {
	var pw1 = document.getElementById("pw1").value;
	var pw2 = document.getElementById("pw2").value;
	if(pw1 == pw2) {
	document.getElementById("tip").innerHTML="<font></font>";
	document.getElementById("submit").disabled = false;
	}
	else {
	document.getElementById("tip").innerHTML="<font color='yellow'><br><b>Passwords don't match.</b></font>";
	document.getElementById("submit").disabled = true;
	}
}