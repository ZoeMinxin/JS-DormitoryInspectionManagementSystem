  //option selecte true
  function Get_Selected_Id(place){
    var pro = document.getElementById(place);
    var Selected_Id = pro.options[pro.selectedIndex].id;
    return Selected_Id;   //back selected true
   }
   //2
   function Get_Next_Place(This_Place_ID,Action){
    var Selected_Id = Get_Selected_Id(This_Place_ID); //Selected_Id from 1
    if(Action=='Get_place')       
     Add_place(Selected_Id);
    else if(Action=='Get_number')
     Add_number(Selected_Id);
   }
  
   var Place_dict = {
    "David Russell Apartments":{
        "Kitchen":["K2","K3","K4"],
        "Room":["M2","M3","M4"],
        "Common Place":["Game Room 1","Game Room 2","Laundry Room"]
        },
    "Powell Hall":{
        "Kitchen":["A1","A2"],
        "Room":["A1","A2"],
        "Common Place":["Game Room","Laundry Room","Study Room"]
        }
   };
   
   function Add_place(residence_Selected_Id){
    $("#place").empty();
    $("#place").append("<option>CHOOSE ROOM TYPE</option>");
    $("#number").empty();
    $("#number").append("<option>CHOOSE ROOM</option>");
   
    var residence_dict = Place_dict[residence_Selected_Id]; 
    for(place in residence_dict){  
     
     var text = "<option"+" id='"+place+"'>"+place+"</option>";
     $("#place").append(text);
     //console.log(text); 
    }
   }
  
   function Add_number(place_Selected_Id){
    $("#number").empty();
    $("#number").append("<option>CHOOSE ROOM</option>");
   
    var residence_Selected_ID = Get_Selected_Id("residence"); 
    var number_list = Place_dict[residence_Selected_ID][place_Selected_Id]; 
    for(index in number_list){
    
     var text = "<option"+" id=\'"+number_list[index]+"\'>"+number_list[index]+"</option>";
     $("#number").append(text);
     //console.log(text); 
    }
   }