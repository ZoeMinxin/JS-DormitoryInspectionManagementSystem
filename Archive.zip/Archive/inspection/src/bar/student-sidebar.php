<!DOCTYPE html>
<html lang="en">

<body>

<!-- Start wrapper-->
<div id="wrapper">

<!--Start sidebar-wrapper-->
 <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
   <div class="brand-logo">
     <img src="../../images/s2.png" width="172px" height="50px" alt="logo icon">
 </div>
 <div class="user-details">
  <div class="media align-items-center user-pointer collapsed" data-toggle="collapse" data-target="#user-dropdown">
    <div class="avatar"><img class="mr-3 side-user-img" src="../../images/student.png" alt="user avatar"></div>
     <div class="media-body">

       <?php
        echo "<h6 class='side-user-name'>$stu_name</h6>";
       ?><!-- get name from dbms -->
      
    </div>
     </div>
   <div id="user-dropdown" class="collapse">
    <ul class="user-setting-menu">
      <li><a href="student-profile.php"><i class="icon-user"></i>  My Profile</a></li> <!-- get id, name, email from dbms -->
      <li><a href="student-inbox.php"><i class="icon-envelope"></i> Inbox</a></li>
      <li><a href="student-login.html"><i class="icon-power"></i> Logout</a></li>
    </ul>
   </div>
    </div>
 <ul class="sidebar-menu do-nicescrol">
    <li>
      <a href="javaScript:void();" class="waves-effect">
      <i class="zmdi zmdi-calendar-check"></i> <span>Coming Inspections</span> <i class="fa fa-angle-left pull-right"></i>
      </a>
      <ul class="sidebar-submenu">
        <li><a href="student-view-time-K.php"><i class="zmdi zmdi-long-arrow-right"></i> Kitchen</a></li>
        <li><a href="student-view-time-R.php"><i class="zmdi zmdi-long-arrow-right"></i> Room</a></li>
      </ul>
    </li>
    <li>
      <a href="javaScript:void();" class="waves-effect">
      <i class="zmdi zmdi-layers"></i> <span>View Record</span> <i class="fa fa-angle-left pull-right"></i>
      </a>
      <ul class="sidebar-submenu">
        <li><a href="student-view-record-K.php"><i class="zmdi zmdi-long-arrow-right"></i> Kitchen</a></li>
        <li><a href="student-view-record-R.php"><i class="zmdi zmdi-long-arrow-right"></i> Room</a></li>
      </ul>
    </li>
    <li>
      <a href="student-facility.php" class="waves-effect">
      <i class="zmdi zmdi-card-travel"></i> <span>Facility Damage</span></i>
      </a>
    </li>

  </ul>
 
 </div>
 <!--End sidebar-wrapper-->
   </body>

   </html>