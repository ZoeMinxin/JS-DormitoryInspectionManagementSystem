<!DOCTYPE html>
<html lang="en">

<body>

<!--Start topbar header-->
<header class="topbar-nav">
 <nav class="navbar navbar-expand fixed-top">
  <ul class="navbar-nav mr-auto align-items-center">
    <li class="nav-item">
      <a class="nav-link toggle-menu" href="javascript:void();">
       <i class="icon-menu menu-icon"></i>
     </a>
    </li>
    <li class="nav-item">
    <div class="container">
        <div class="text-center text-white">
            © 2019 The University of St Andrews is a charity registered in Scotland, No: SC013532
        </div>
      </div>
    </li>
  </ul>
     
  <ul class="navbar-nav align-items-center right-nav-link">
    <li class="nav-item">
      <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown" href="#">
        <span class="user-profile"><img src="../../images/staff.png" class="img-circle" style="border:1px solid white" alt="user avatar"></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-right">
       <li class="dropdown-item user-details">
        <a href="javaScript:void();">
           <div class="media">
             <div class="avatar"><img class="align-self-start mr-3" src="../../images/staff.png" alt="user avatar"></div>
            <div class="media-body">
              <?php
                echo "<h6 class='mt-2 user-title'>$staff_name</h6>";
                echo "<p class='user-subtitle'>$staff_email</p>";
              ?>
            </div>
           </div>
          </a>
        </li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><a href="../staff/staff-profile.php"><i class="icon-user mr-2"></i> Profile</a></li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><a href="../staff/staff-inbox.php"><i class="icon-envelope mr-2"></i> Inbox</a></li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><a href="../staff/staff-login.html"><i class="icon-power mr-2"></i> Logout</a></li>
      </ul>
    </li>
  </ul>
</nav>
</header>
<!--End topbar header-->

</body>

</html>