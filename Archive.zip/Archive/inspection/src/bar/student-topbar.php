<!DOCTYPE html>
<html lang="en">

<body>

<!--Start topbar header-->
<header class="topbar-nav">
 <nav class="navbar navbar-expand fixed-top">
  <ul class="navbar-nav mr-auto align-items-center">
    <li class="nav-item">
      <a class="nav-link toggle-menu" href="javascript:void();">
       <i class="icon-menu menu-icon"></i>
     </a>
    </li>
    <li class="nav-item">
    <div class="container">
        <div class="text-center text-white">
            <?php
              $sql="SELECT r_name, kit_no, room_no, move_in_date
              from occupies
              where stu_id = '$stu_id'";
          
              $result = mysqli_query($conn, $sql);
          
              while ($row = mysqli_fetch_array ($result))
              {
                echo "Residence:";
                echo $row["r_name"];
                echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kitchen Number:";
                echo $row["kit_no"];
                echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Room Number:";
                echo $row["room_no"];
              }
            ?>
        </div>
      </div>
    </li>
  </ul>
     
  <ul class="navbar-nav align-items-center right-nav-link">
    <li class="nav-item">
      <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown" href="#">
        <span class="user-profile"><img src="../../images/student.png" class="img-circle" style="border:1px solid white" alt="user avatar"></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-right">
       <li class="dropdown-item user-details">
        <a href="javaScript:void();">
           <div class="media">
             <div class="avatar"><img class="align-self-start mr-3" src="../../images/student.png" alt="user avatar"></div>
            <div class="media-body">
              <?php
                echo "<h6 class='mt-2 user-title'>$stu_name</h6>";
                echo "<p class='user-subtitle'>$stu_email</p>";
              ?>
            </div>
           </div>
          </a>
        </li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><a href="student-profile.php"><i class="icon-user mr-2"></i> Profile</a></li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><a href="student-inbox.php"><i class="icon-envelope mr-2"></i> Inbox</a></li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><a href="student-login.html"><i class="icon-power mr-2"></i> Logout</a></li>
      </ul>
    </li>
  </ul>
</nav>
</header>
<!--End topbar header-->

</body>

</html>