<?php

session_start();

if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //check if "submit" acted 

include ('../../bar/connect.php');
$conn = OpenCon();

$Staff_id=$_POST['Staff_id'];
$Staff_pwd=$_POST['Staff_pwd'];


if($Staff_id && $Staff_pwd){
    $checkstaff = "SELECT * FROM staff WHERE Staff_id='$Staff_id' and Staff_pwd='$Staff_pwd'";
    $result = mysqli_query($conn, $checkstaff);
    $rows=mysqli_num_rows($result);
    if($rows){
        header("refresh:0; url= ../staff.php");
        $_SESSION["Staff_id"]=$Staff_id;                          //store id

        $findname=" select * from staff where Staff_id='$Staff_id'";
        $nameresult = mysqli_query ($conn, $findname);

        while ($rowstaffname =mysqli_fetch_array($nameresult))
        {
            $_SESSION["Staff_name"] = $rowstaffname['Staff_name'];    //store name
        }                                                   

        $findemail=" select * from staff where Staff_id='$Staff_id'";
        $emailresult = mysqli_query ($conn, $findemail);
       
        while ($rowstaffemail =mysqli_fetch_array($emailresult))
        {
            $_SESSION["Staff_email"] = $rowstaffemail['Staff_email'];      //store email
        }       

        exit;
    }

    else{
        echo "Wrong staff ID or Password";
        echo "
        <script>
            setTimeout(function(){window.location.href='../staff-login.html';},2000);
        </script>
        ";
    }
}
else{
    echo "Please complete your staff ID and password";
    echo "
        <script>
            setTimeout(function(){window.location.href='../staff-login.html';},2000);
        </script>
        ";

}


mysqli_close($conn);


?>