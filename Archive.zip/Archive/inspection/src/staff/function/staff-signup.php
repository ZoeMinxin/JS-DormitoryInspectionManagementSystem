<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

include ('../../bar/connect.php');
$conn = OpenCon();

$Staff_id = $_POST['Staff_id'];
$Staff_name = $_POST['Staff_name'];
$Staff_email = $_POST['Staff_email'];
$Staff_pwd = $_POST['Staff_pwd'];

$exist="select Staff_id from staff where Staff_id='$Staff_id'";
$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if(!$erow)
{
  if(strlen($Staff_id) == 5){
    $qu = "INSERT INTO staff VALUES ('$Staff_id', '$Staff_name','$Staff_email','$Staff_pwd')";
    $result = mysqli_query($conn, $qu);
    
    if(!$result){
        echo "
        <script>
            setTimeout(function(){window.location.href='../staff-login.html';},2500);
        </script>
        ";
    
    }
    else{
        echo "Sign up successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-login.html';},2500);
            </script>
            ";
    
    
    }
  } else {
    echo "Your ID is not a 5-digit number! Please check your Staff ID again!";
    echo "
        <script>
            setTimeout(function(){window.location.href='../staff-signup.html';},3000);
        </script>
        ";
  }
}
else
{

    echo "Your ID has been signed up already!";
    echo "
        <script>
            setTimeout(function(){window.location.href='/inspection/staff-login.html';},2500);
        </script>
        ";
}







mysqli_close($conn);


?>