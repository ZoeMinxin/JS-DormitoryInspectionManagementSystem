<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

$reply_time = date('Y-m-d H:i:s');;// submit button clicking time

session_start();
$in_id=$_SESSION["Staff_id"];

include ('../../bar/connect.php');
$conn = OpenCon();

$out_id = $_POST['out_id'];
$subject = $_POST['subject'];
$content = $_POST['content'];
$send_time = $_POST['send_time'];
$reply = $_POST['reply'];

$exist="select out_id,send_time,subject,content
        from inbox 
        where out_id='$out_id'
        and send_time='$send_time'
        and subject='$subject'
        and content='$content'";

$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if($erow)
{
    $qu = "UPDATE inbox
    SET in_id='$in_id', reply=replace(replace('$reply',char(10),''),char(13),''), reply_time='$reply_time', status='read'
    WHERE out_id='$out_id'
        and send_time='$send_time'
        and subject='$subject'
        and content='$content'";
    $result = mysqli_query($conn, $qu);
    
    if(!$result){
        echo "Please reply!";
        echo "
        <script>
            setTimeout(function(){window.location.href='../staff-inbox.php';},2000);
        </script>
        ";
    
    }
    else{
        echo "Send successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-inbox.php';},2000);
            </script>
            ";
    
    
    }
   
}
else
{

    echo "The mail does not exist!";
    echo "
        <script>
            setTimeout(function(){window.location.href='../staff-inbox.php';},2000);
        </script>
        ";
}







mysqli_close($conn);


?>