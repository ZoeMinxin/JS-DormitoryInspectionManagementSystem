<?php

include ('../../bar/connect.php');
    $conn = OpenCon();

// header("Content-Type: text-html; charset=utf-8");
if (isset($_POST["submit-in-process"])){

    $r_name = $_POST['r_name'];
    $damage_place = $_POST['damage_place'];
    $report_time = $_POST['report_time'];
    $report_id = $_POST['report_id'];
    $status1 = $_POST['status-in-process'];
    $other_info = $_POST['other_info'];
    
    $exist="select r_name,damage_place,report_time,report_id
            from damage 
            where r_name='$r_name'
            and damage_place='$damage_place'
            and report_time='$report_time'
            and report_id='$report_id'";
    
    $ere=mysqli_query($conn, $exist);
    $erow=mysqli_num_rows($ere);
    if($erow)
    {
        $qu = "UPDATE damage 
        SET status='$status1', other_info=replace(replace('$other_info',char(10),'->'),char(13),'')
        WHERE r_name='$r_name'
            and damage_place='$damage_place'
            and report_time='$report_time'
            and report_id='$report_id'";
        $result = mysqli_query($conn, $qu);
        
        if(!$result){
            echo "
            <script>
                setTimeout(function(){window.location.href='../staff-repair-damage.php';},2000);
            </script>
            ";
        
        }
        else{
            echo "Change damage report status successfully!";
            echo "
                <script>
                    setTimeout(function(){window.location.href='../staff-repair-damage.php';},2000);
                </script>
                ";
        
        
        }
       
    }
    else
    {
    
        echo "The damage does not exist!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-repair-damage.php';},2000);
            </script>
            ";
    }
    
    
    
    //mysqli_close($conn);
} 

if(isset($_POST["submit-finish"])){

    $finish_time = date('Y-m-d H:i:s');;// submit button clicking time

    //include ('../../bar/connect.php');
    //$conn = OpenCon();
    
    $r_name = $_POST['r_name'];
    $damage_place = $_POST['damage_place'];
    $report_time = $_POST['report_time'];
    $report_id = $_POST['report_id'];
    $status2 = $_POST['status-finish'];
    $other_info = $_POST['other_info'];
    
    $exist="select r_name,damage_place,report_time,report_id
            from damage 
            where r_name='$r_name'
            and damage_place='$damage_place'
            and report_time='$report_time'
            and report_id='$report_id'";
    
    $ere=mysqli_query($conn, $exist);
    $erow=mysqli_num_rows($ere);
    if($erow)
    {
        $qu = "UPDATE damage 
        SET status='$status2',finish_time='$finish_time', other_info=replace(replace('$other_info',char(10),'->'),char(13),'')
        WHERE r_name='$r_name'
            and damage_place='$damage_place'
            and report_time='$report_time'
            and report_id='$report_id'";
    
    
        $result = mysqli_query($conn, $qu);
        
        if(!$result){
            echo "
            <script>
                setTimeout(function(){window.location.href='../staff-repair-damage.php';},2000);
            </script>
            ";
        
        }
        else{
            echo "The damaged facility has been fixed successfully!";
            echo "
                <script>
                    setTimeout(function(){window.location.href='../staff-repair-damage.php';},2000);
                </script>
                ";
        
        
        }
       
    }
    else
    {
    
        echo "The damage does not exist!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-repair-damage.php';},2000);
            </script>
            ";
    }
    
    
    
   
}

 mysqli_close($conn);
?>