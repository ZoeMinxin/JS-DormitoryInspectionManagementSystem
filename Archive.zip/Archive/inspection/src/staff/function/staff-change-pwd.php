<?php

// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

session_start();
$staff_id=$_SESSION["Staff_id"];

include ('../../bar/connect.php');
$conn = OpenCon();

$Staff_pwd = $_POST['Staff_pwd'];
$Staff_pwd2 = $_POST['Staff_pwd2'];
$Staff_pwdcheck = "select Staff_pwd from staff where Staff_id='$staff_id'";

$ere=mysqli_query($conn, $Staff_pwdcheck);
$pwdcheck = mysqli_fetch_array($ere);

if(! $ere){
    die("Could not connect: " . mysql_error());
}
else{
    if($Staff_pwd == $pwdcheck['Staff_pwd']){
        $sql = "UPDATE staff
            SET Staff_pwd = '$Staff_pwd2'
            WHERE Staff_id = '$staff_id'
            ";

        $result = mysqli_query($conn, $sql);


        if(!$result){
            echo "
            <script>
                setTimeout(function(){window.location.href='../staff-profile.php';},1500);
            </script>
            ";
    
        }
        else{
       
        echo "Updated new password successfully.\n Please login with new password again!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-login.html';},2000);
            </script>
            ";
        }
    }

    else{
        echo "Your original passwords don't match.";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-profile.php';},2000);
            </script>
            ";
    }
}





mysqli_close($conn);


?>