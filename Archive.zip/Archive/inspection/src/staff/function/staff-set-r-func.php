<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

$date_clicked = date('Y-m-d H:i:s');;// submit button clicking time

include ('../../bar/connect.php');
$conn = OpenCon();

$r_name = $_POST['r_name'];
$room_no = $_POST['room_no'];
$staff_id = $_POST['Staff_id'];
$est_timer = $_POST['est_timer'];
$check_staff = $_POST['check_staff'];
$shower_room = $_POST['shower_room'];
$sink_r = $_POST['sink_r'];
$mirror_bed = $_POST['mirror_bed'];
$mirror_wash = $_POST['mirror_wash'];
$toilet = $_POST['toilet'];
$bin = $_POST['bin'];
$safety_notice = $_POST['safety_notice'];
$poster = $_POST['poster'];
$wall_r = $_POST['wall_r'];
$carpet_r = $_POST['carpet_r'];
$skirting = $_POST['skirting'];
$set_otherr = $_POST['set_otherr'];
$result_r = $_POST['result_r'];
$est_timer2 = $_POST['est_timer2'];

$exist="select r_name,room_no,Staff_id,est_timer 
        from inspection_r 
        where r_name='$r_name'
        and room_no='$room_no'
        and Staff_id='$staff_id'
        and est_timer='$est_timer'";

$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if($erow)  //if exist
{
    if($result_r == 'PASS'){  //pass -->insert result only
    $qu = "UPDATE inspection_r 
            SET check_staff='$check_staff',shower_room='$shower_room',sink_r='$sink_r',mirror_bed='$mirror_bed',mirror_wash='$mirror_wash',toilet='$toilet',bin='$bin',safety_notice='$safety_notice',poster='$poster',wall_r='$wall_r',carpet_r='$carpet_r',skirting='$skirting',set_otherr='$set_otherr',result_r='$result_r',check_timer='$date_clicked'
            WHERE r_name='$r_name'
                and room_no='$room_no'
                and Staff_id='$staff_id'
                and est_timer='$est_timer'";
    $result = mysqli_query($conn, $qu);

    if(!$result){
        echo "
        <script>
            setTimeout(function(){window.location.href='../staff-set-time-R.php';},2000);
        </script>
        ";
    
    }
    else{
        echo "Insert room inspection result successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-set-result-R.php';},2000);
            </script>
            ";
    
    
    }

    }
    else{  //fail-->insert result and insert new time
        $qu1 = "UPDATE inspection_r 
        SET check_staff='$check_staff',shower_room='$shower_room',sink_r='$sink_r',mirror_bed='$mirror_bed',mirror_wash='$mirror_wash',toilet='$toilet',bin='$bin',safety_notice='$safety_notice',poster='$poster',wall_r='$wall_r',carpet_r='$carpet_r',skirting='$skirting',set_otherr='$set_otherr',result_r='FAIL',check_timer='$date_clicked'
        WHERE r_name='$r_name'
            and room_no='$room_no'
            and Staff_id='$staff_id'
            and est_timer='$est_timer'";
            
        $qu2 = "INSERT INTO inspection_r (r_name,room_no,Staff_id,est_timer)
            VALUES ('$r_name', '$room_no','$staff_id','$est_timer2')";

        $result1 = mysqli_query($conn, $qu1);
        $result2 = mysqli_query($conn, $qu2);

    if(!$result1 && !$result2){
        echo "
        <script>
            setTimeout(function(){window.location.href='../staff-set-time-R.php';},2000);
        </script>
        ";
    
    }
    else{
        echo "Insert room inspection result successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-set-result-R.php';},2000);
            </script>
            ";
    
    
    }
}

    
   
}
else  //does not exist
{

    echo "The inspection time of this room has NOT been inserted yet!";
    echo "
        <script>
            setTimeout(function(){window.location.href='/inspection/src/staff-settimeR.php';},2000);
        </script>
        ";
}







mysqli_close($conn);


?>