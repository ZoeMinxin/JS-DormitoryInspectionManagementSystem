<?php

// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

session_start();
$staff_id=$_SESSION["Staff_id"];

include ('../../bar/connect.php');
$conn = OpenCon();

$Staff_email = $_POST['Staff_email'];
$Staff_email2 = $_POST['Staff_email2'];
$Staff_emailcheck = "select Staff_email from staff where Staff_id='$staff_id'";

$ere=mysqli_query($conn, $Staff_emailcheck);
$emailcheck = mysqli_fetch_array($ere);

if(! $ere){
    die("Could not connect: " . mysql_error($conn));
}
else{
    if($staff_email = $emailcheck['Staff_email']){
        $sql = "UPDATE staff
            SET Staff_email = '$Staff_email2'
            WHERE Staff_id = '$staff_id'
            ";

        $result = mysqli_query($conn, $sql);


        if(!$result){
            echo "
            <script>
                setTimeout(function(){window.location.href='../staff-profile.php';},2000);
            </script>
            ";
    
        }
        else{
        echo "Updated new email successfully.\n Please login again!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-login.html';},2000);
            </script>
            ";
        }
    }

    else{
        echo "Your original email doesn't match.";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-profile.php';},2000);
            </script>
            ";
    }
}





mysqli_close($conn);


?>