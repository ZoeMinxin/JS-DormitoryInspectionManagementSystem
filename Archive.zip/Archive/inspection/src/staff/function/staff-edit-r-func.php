<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 


include ('../../bar/connect.php');
$conn = OpenCon();

$r_name = $_POST['r_name'];
$room_no = $_POST['room_no'];
$staff_id = $_POST['Staff_id'];
$est_timer = $_POST['est_timer'];
$check_staff = $_POST['check_staff'];
$est_timer2 = $_POST['est_timer2'];
$est_timer2 = str_replace('T',' ',$est_timer2);

$exist="select r_name,room_no,Staff_id,est_timer 
        from inspection_r 
        where r_name='$r_name'
        and room_no='$room_no'
        and Staff_id='$staff_id'
        and est_timer='$est_timer'";

$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if($erow)  //if exist
{
  if($est_timer2 !== $est_timer){
    $qu = "UPDATE inspection_r 
            SET Staff_id='$check_staff',est_timer='$est_timer2'
            WHERE r_name='$r_name'
                and room_no='$room_no'
                and Staff_id='$staff_id'
                and est_timer='$est_timer'";
    $result = mysqli_query($conn, $qu);

    if(!$result){
        echo "
        <script>
            setTimeout(function(){window.location.href='../staff-set-result-R.php';},2000);
        </script>
        ";
    
    }
    else{
        echo "Change room inspection time successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-set-result-R.php';},2000);
            </script>
            ";
    
    
    }
  }else{
      echo "The time you select is the same as the scheduled one!";
      echo "
            <script>
                setTimeout(function(){window.location.href='../staff-edit-r.php?r_name=$r_name+&room_no=$room_no&Staff_id=$staff_id&est_timer=$est_timer&check_staff=$check_staff';},2000);
            </script>
            ";
  }
    
}

else  //does not exist
{

    echo "The inspection time of this room has NOT been inserted yet!";
    echo "
        <script>
            setTimeout(function(){window.location.href='../staff-set-time-R.php';},2000);
        </script>
        ";
}







mysqli_close($conn);


?>