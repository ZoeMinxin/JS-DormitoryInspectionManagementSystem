<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

$date_clicked = date('Y-m-d H:i:s');;// submit button clicking time

include ('../../bar/connect.php');
$conn = OpenCon();

$r_name = $_POST['r_name'];
$kit_no = $_POST['kit_no'];
$staff_id = $_POST['Staff_id'];
$est_timek = $_POST['est_timek'];
$check_staff = $_POST['check_staff'];
$microwave = $_POST['microwave'];
$fridge = $_POST['fridge'];
$surface = $_POST['surface'];
$cooker = $_POST['cooker'];
$set_otherk = $_POST['set_otherk'];
$sink_k = $_POST['sink_k'];
$rubbish = $_POST['rubbish'];
$wall_k = $_POST['wall_k'];
$carpet_k = $_POST['carpet_k'];
$result_k = $_POST['result_k'];
$est_timek2 = $_POST['est_timek2'];

$exist="select r_name,kit_no,Staff_id,est_timek 
        from inspection_k 
        where r_name='$r_name'
        and kit_no='$kit_no'
        and Staff_id='$staff_id'
        and est_timek='$est_timek'";

$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if($erow)  //if exist
{
    if($result_k == 'PASS'){  //pass -->insert result only
    $qu = "UPDATE inspection_k 
            SET check_staff='$check_staff',microwave='$microwave',fridge='$fridge',surface='$surface',cooker='$cooker',sink_k='$sink_k',rubbish='$rubbish',wall_k='$wall_k',carpet_k='$carpet_k',set_otherk='$set_otherk',result_k='$result_k',check_timek='$date_clicked'
            WHERE r_name='$r_name'
                and kit_no='$kit_no'
                and Staff_id='$staff_id'
                and est_timek='$est_timek'";
    $result = mysqli_query($conn, $qu);

    if(!$result){
        echo "
        <script>
            setTimeout(function(){window.location.href='../staff-set-time-K.php';},2000);
        </script>
        ";
    
    }
    else{
        echo "Insert kitchen inspection result successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-set-result-K.php';},2000);
            </script>
            ";
    
    
    }

    }
    else{  //fail-->insert result and insert new time
        $qu1 = "UPDATE inspection_k 
        SET check_staff='$check_staff',microwave='$microwave',fridge='$fridge',surface='$surface',cooker='$cooker',sink_k='$sink_k',rubbish='$rubbish',wall_k='$wall_k',carpet_k='$carpet_k',set_otherk='$set_otherk',result_k='FAIL',check_timek='$date_clicked'
        WHERE r_name='$r_name'
            and kit_no='$kit_no'
            and Staff_id='$staff_id'
            and est_timek='$est_timek'";
            
        $qu2 = "INSERT INTO inspection_k (r_name,kit_no,Staff_id,est_timek)
            VALUES ('$r_name', '$kit_no','$check_staff','$est_timek2')";

        $result1 = mysqli_query($conn, $qu1);
        $result2 = mysqli_query($conn, $qu2);

    if(!$result1 && !$result2){
        echo "
        <script>
            setTimeout(function(){window.location.href='../staff-set-time-K.php';},2000);
        </script>
        ";
    
    }
    else{
        echo "Insert kitchen inspection result successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../staff-set-result-K.php';},2000);
            </script>
            ";
    
    
    }
}

    
   
}
else  //does not exist
{

    echo "The inspection time of this kitchen has NOT been inserted yet!";
    echo "
        <script>
            setTimeout(function(){window.location.href='../staff-set-time-K.php';},2000);
        </script>
        ";
}


mysqli_close($conn);


?>