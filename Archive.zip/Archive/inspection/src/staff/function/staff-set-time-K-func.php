<?php

// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

session_start();
$staff_id=$_SESSION["Staff_id"];

include ('../../bar/connect.php');
$conn = OpenCon();

$r_name = $_POST['r_name'];
$kit_no = $_POST['kit_no'];
$est_timek = $_POST['est_timek'];
$est_timek = str_replace('T',' ',$est_timek);


$exist="select r_name,kit_no,Staff_id,est_timek 
        from inspection_k 
        where r_name='$r_name'
        and kit_no='$kit_no'
        and Staff_id='$staff_id'
        and est_timek='$est_timek'";

$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);

if(!$erow)
{

    if($r_name != null && $kit_no != null && $est_timek != null){
        $qu = "INSERT INTO inspection_k (r_name,kit_no,Staff_id,est_timek)
        VALUES ('$r_name', '$kit_no','$staff_id','$est_timek')";
        $result = mysqli_query($conn, $qu);
        
        if(!$result){
            echo "Please insert all information!";
            echo "
            <script>
                setTimeout(function(){window.location.href='../staff-set-time-K.php';},2000);
            </script>
            ";
    
        }
        else{
            echo "Insert kitchen inspection time successfully!";
            echo "
                <script>
                    setTimeout(function(){window.location.href='../staff-set-time-K.php';},2000);
                </script>
                ";

        }
       
    }

}
else
{

    echo "The inspection time of this kitchen has been inserted already!";
    echo "
        <script>
            setTimeout(function(){window.location.href='../staff-set-time-K.php';},2000);
        </script>
        ";
}



mysqli_close($conn);


?>