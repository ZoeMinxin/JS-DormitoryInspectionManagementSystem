<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title"><a href="staff-view-record-K.php" class="text-danger">KITCHEN</a> INSPECTION RESULT</h4>
            </div>
        </div>
      
    <div class="row">
        <div class="col-lg-12">
          <div class="card">
            
            <div class="card-body">
              <div class="table-responsive">
              <table id="default-datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Residence</th>
                        <th>Kitchen</th>
                        <th>Inspector</th>
                        <th>Inspection Time</th>
                        <th>Inspection Result</th>
                        <th>Status</th>
                    </tr>
                </thead>


                <tbody>

<?php
    $sql="SELECT r_name, kit_no, Staff_id, est_timek, check_staff, check_timek, result_k
    from inspection_k
    where result_k is not null";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {
    //$num=$num+1;
    //echo $row;
   // }
?>
                  
                    <tr>
                     
                        <td><?php echo $row["r_name"] ?></td>
                        <td><?php echo $row["kit_no"] ?></td>
                        <td><?php echo $row["check_staff"] ?></td>
                        <td><?php echo $row["check_timek"] ?></td>
                        <td><?php echo $row["result_k"] ?></td>
                        <td><button type="submit" class="btn btn-outline-primary waves-effect waves-light m-1" onclick="window.location.href='<?php echo "staff-view-k.php?r_name=".$row['r_name'];?>+<?php echo "&kit_no=".$row['kit_no'];?>+<?php echo "&Staff_id=".$row['Staff_id'];?>+<?php echo "&est_timek=".$row['est_timek'];?>+<?php echo "&check_staff=".$row['check_staff'];?>+<?php echo "&check_timek=".$row['check_timek'];?>+<?php echo "&result_k=".$row['result_k'];?>'">View Result</button></td>
                    </tr>
                  
<?php
    }
    
?>
                </tbody>
              </table>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

    
    </div><!--End content-wrapper-->

  </div>
  
</body>
</html>
