<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">DAMAGE REPORTS</h4>
            </div>
        </div>
      
    <div class="row">
        <div class="col-lg-12">
          <div class="card">
            
            <div class="card-body">
              <div class="table-responsive">
              <table id="default-datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Residence</th>
                        <th>Damage Place</th>
                        <th>Damage Information</th>
                        <th>Finish Time</th>
                        <th>View Detail</th>
                    </tr>
                </thead>


                <tbody>

<?php
    $sql="SELECT r_name, damage_place, report_time, report_id, damage_info, finish_time
    from damage
    where status='finish'";

    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {
?>
                  
                    <tr>
                     
                        <td><?php echo $row["r_name"] ?></td>
                        <td><?php echo $row["damage_place"] ?></td>
                        <td><?php echo $row["damage_info"] ?></td>
                        <td><?php echo $row["finish_time"] ?></td>
                        <td><button type="submit" class="btn btn-outline-primary waves-effect waves-light m-1" onclick="window.location.href='<?php echo "staff-finished.php?r_name=".$row['r_name'];?>+<?php echo "&damage_place=".$row['damage_place'];?>+<?php echo "&report_id=".$row['report_id'];?>+<?php echo "&report_time=".$row['report_time'];?>'">View Detail</button></td>
                    </tr>
                  
<?php
    }
    
?>
                </tbody>
              </table>
              <hr/>
              <a href="staff-facility.php"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

    
    </div><!--End content-wrapper-->	
   
  </div>
  
</body>
</html>
