<!DOCTYPE html>
<html ng-app="app" lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">SET <a href="staff-set-time-R.php" class="text-danger">ROOM</a> INSPECTION TIME</h4>
            </div>
        </div>

        <div class="row">
        <div class="col-lg-12">
          <div class="card">
              <div class="card-body">
                <form action="function/staff-set-time-R-func.php" name="r_nameandroom_no" method="POST">
                <div class="form-group col-md-12">
                  <label for="input-2">- Choose University Residence* -</label>
                  <div class="row">
                    <div class="col-md-4">
                    <select class="form-control" name="r_name" id="r_name" onchange="getroom_noName()">
                      <option value="0">Please select the residence</option>
                    </select>
                    
                    </div>
                  </div>
                </div>

                  <hr/>

                  <div class="form-group col-md-4">
                    <label for="input-2">- Room Number* -</label>
                    <select class="form-control" name="room_no">
                     <option value="0">Please select the room number</option>
                    </select>
                  </div>

                  <hr/>

                  <div class="form-group col-md-4">
                    <label for="input-2">- Time* -</label>
                    <input class="form-control" type="datetime-local" name="est_timer" id="est_timer" required>
                  </div>

                  <hr/>

                <div class="form-group col-md-8">
                    <button type="submit" class="btn btn-primary px-5" name="submit"><i class="icon-lock"></i> Upload</button>
                </div>
                
                </form>
              </div>
            </div>
          </div>
        </div><!-- End Row-->



    </div>
  </div><!--End Row-->

    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->

<script>
var r_name = ["David Russell Apartments", "Powell Hall"];
var collect = document.getElementById("r_name")
var old = collect.innerHTML
function aa() {
    var r_nameno = " "
    for (var j = 0; j < r_name.length; j++) {
      r_nameno += '<option>' + r_name[j] + '</option>';
    }
    collect.innerHTML = old + r_nameno;
}      
aa();  
var room_noName = [
    ["M2", "M3", "M4"],
    ["A1", "A2"]
];
 
function getroom_noName() {
    var r_nameNo = document.r_nameandroom_no.r_name;
    var room_noNo = document.r_nameandroom_no.room_no;
    var R_nameRoom_no = room_noName[r_nameNo.selectedIndex - 1];
    room_noNo.length = 1;
    for (var i = 0; i < R_nameRoom_no.length; i++) {
      room_noNo[i + 1] = new Option(R_nameRoom_no[i], R_nameRoom_no[i]);
    }
}
</script>
	
<script>// set date only greater than today
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();
var hh = today.getHours();
var min = today.getMinutes();
 /**/ if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    if(hh<10){
        hh='0'+hh
    } 
    if(min<10){
        min='0'+min
    }

var today = yyyy+'-'+mm+'-'+dd+'T'+hh+':'+min;


document.getElementById("est_timer").min=today;

</script>

</body>
</html>