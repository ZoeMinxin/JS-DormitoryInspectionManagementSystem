<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title"><a href="staff-set-k.php" class="text-danger">KITCHEN</a> INSPECTION RESULT</h4>
            </div>
        </div>

        <div class="row">
        <div class="col-lg-12">
          <div class="card">
              <div class="card-body">
                
                <div class="form-group col-md-12">

<form action="function/staff-set-k-func.php" method="post">
                <div class="form-group col-md-6">
                  <label for="input-2">- University Residence -</label>
                  <input type="hidden" name="r_name" value="<?php $r_name= $_GET['r_name']; echo $r_name; ?>">
                  <div>
                    <?php
                    $r_name = $_GET['r_name'];
                    echo "<p class='mt-2'>$r_name</p>";
                    ?>
                  </div>
                  </div>                

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-2">- Kitchen Number -</label>
                    <input type="hidden" name="kit_no" value="<?php $kit_no= $_GET['kit_no']; echo $kit_no;?>">
                    <div>
                    <?php
                    $kit_no = $_GET['kit_no'];
                    echo "<p class='mt-2'>$kit_no</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-2">- Scheduled Inspector -</label>
                    <input type="hidden" name="Staff_id" value="<?php $Staff_id= $_GET['Staff_id']; echo $Staff_id;?>">
                    <div>
                    <?php
                    $Staff_id = $_GET['Staff_id'];
                    echo "<p class='mt-2'>$Staff_id</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-3">- Scheduled Inspection Time -</label>
                    <input type="hidden" name="est_timek" value="<?php $est_timek= $_GET['est_timek']; echo $est_timek;?>">
                    <div>
                    <?php
                    $est_timek = $_GET['est_timek'];
                    echo "<p class='mt-2'>$est_timek</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-3">- Inspector -</label>
                    <input type="hidden" name="check_staff" value="<?php $check_staff= $_GET['check_staff']; echo $check_staff;?>">
                    <div>
                    <?php
                    $check_staff = $_GET['check_staff'];
                    echo "<p class='mt-2'>$check_staff</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group col-md-8">
                            <label>MICROWAVE</label>
                            <select class="form-control single-select" name="microwave">
                                <option>GOOD</option>
                                <option>NEED MORE CLEANING</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>FRIDGE</label>
                            <select class="form-control single-select" name="fridge">
                                <option>GOOD</option>
                                <option>NEED MORE CLEANING</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>SURFACES</label>
                            <select class="form-control single-select" name="surface">
                                <option>GOOD</option>
                                <option>NEED MORE CLEANING</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>COOKER</label>
                            <select class="form-control single-select" name="cooker">
                                <option>GOOD</option>
                                <option>NEED MORE CLEANING</option>
                            </select>
                        </div>
                        <div class="form-group col-md-8">
                            <label for="input-1">OTHER</label>
                            <input type="text" class="form-control" name="set_otherk" placeholder="Other problems">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group col-md-8">
                            <label>SINK</label>
                            <select class="form-control single-select" name="sink_k">
                                <option>GOOD</option>
                                <option>NEED MORE CLEANING</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>RUBBISH</label>
                            <select class="form-control single-select" name="rubbish">
                                <option>CLEAR</option>
                                <option>PLEASE EMPTY ALL THE RUBBISH</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>WALL</label>
                            <select class="form-control single-select" name="wall_k">
                                <option>GOOD</option>
                                <option>PLEASE WIPE WALLS</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>CARPET</label>
                            <select class="form-control single-select" name="carpet_k">
                                <option>GOOD</option>
                                <option>NEED MORE CLEANING</option>
                            </select>
                        </div> 
                    </div>
                </div><!--End Row-->

                <hr/>

                <div class="row">
                  <div class="col-lg-6">
                    <div class="form-group col-md-8">
                      <label>RESULT</label>

                      <ul class="list" style="list-style-type:none;">
                        <li>
                          <select class="sel form-control single-select" name="result_k">
                            <option>PASS</option>
                            <option value="item1">FAIL</option>
                          </select>
                        </li>
                        <li class="item1">
                          <div class="form-group col-md-12">
                            <br/>
                            <label>- Next Inspection Time* -</label>
                            <input class="form-control" type="datetime-local" name="est_timek2" id="est_timek2">
                          </div>
                        </li>
                      </ul>

                    </div>
                  </div>
                </div>

                <hr/>

                <div class="form-group col-md-12">
                    <button type="submit" class="btn btn-primary px-5" name="submit"><i class="icon-lock"></i> Upload</button>
                    <a href="javascript:history.go(-1)"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
                </div>
                
                </form>
              </div>
            </div>
          </div>
        </div><!-- End Row-->



    </div>
  </div><!--End Row-->

    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->

    <!-- result->fail->set a new time for the same kitchen -->
<script type="text/javascript" src="http://libs.baidu.com/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript">
$(function(){
    $(".list .sel").change(function(event){
        $(".list li[class^=item]").hide();
        this.value.split(",").forEach(function(v){
            $(".list ."+v).show();
        });
    }).change();
});
</script>

<script>// set date only greater than today
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();
var hh = today.getHours();
var min = today.getMinutes();
 /**/ if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    if(hh<10){
        hh='0'+hh
    } 
    if(min<10){
        min='0'+min
    }
var today = yyyy+'-'+mm+'-'+dd+'T'+hh+':'+min;


document.getElementById("est_timek2").min=today;

</script>

</body>
</html>
