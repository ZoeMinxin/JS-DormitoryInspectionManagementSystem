<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title"><a href="staff-view-record-R.php" class="text-danger">ROOM</a> INSPECTION RESULT</h4>
            </div>
        </div>
      
    <div class="row">
        <div class="col-lg-12">
          <div class="card">
            
            <div class="card-body">
              <div class="table-responsive">
              <table id="default-datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Residence</th>
                        <th>Room</th>
                        <th>Inspector</th>
                        <th>Inspection Time</th>
                        <th>Inspection Result</th>
                        <th>Status</th>
                    </tr>
                </thead>


                <tbody>

<?php
    $sql="SELECT r_name, room_no, Staff_id, est_timer, check_staff, check_timer, result_r
    from inspection_r
    where result_r is not null";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {
    //$num=$num+1;
    //echo $row;
   // }
?>
                  
                    <tr>
                     
                        <td><?php echo $row["r_name"] ?></td>
                        <td><?php echo $row["room_no"] ?></td>
                        <td><?php echo $row["check_staff"] ?></td>
                        <td><?php echo $row["check_timer"] ?></td>
                        <td><?php echo $row["result_r"] ?></td>
                        <td><button type="submit" class="btn btn-outline-primary waves-effect waves-light m-1" onclick="window.location.href='<?php echo "staff-view-r.php?r_name=".$row['r_name'];?>+<?php echo "&room_no=".$row['room_no'];?>+<?php echo "&Staff_id=".$row['Staff_id'];?>+<?php echo "&est_timer=".$row['est_timer'];?>+<?php echo "&check_staff=".$row['check_staff'];?>+<?php echo "&check_timer=".$row['check_timer'];?>+<?php echo "&result_r=".$row['result_r'];?>'">View Result</button></td>
                    </tr>
                  
<?php
    }
    
?>
                </tbody>
              </table>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

    
    </div><!--End content-wrapper-->

  </div>

</body>
</html>
