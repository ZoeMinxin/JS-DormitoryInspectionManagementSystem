<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        
      
    <div class="row">
        <div class="col-lg-12">
          <div class="card">
          <div class="card-header"><h4>Kitchen Inspection Result</h4></div>
            <div class="card-body">
              <div class="table-responsive">
               <table class="table table-striped">

                <tbody>

<?php
$r_name = $_GET['r_name'];
$kit_no = $_GET['kit_no'];
$est_timek = $_GET['est_timek'];
$Staff_id = $_GET['Staff_id'];
$check_staff = $_GET['check_staff'];
$check_timek = $_GET['check_timek'];
$result_k = $_GET['result_k'];

    $sql="SELECT r_name, kit_no, est_timek, microwave, fridge, surface, cooker, sink_k, rubbish, wall_k, carpet_k, set_otherk, check_timek, check_staff, result_k
    from inspection_k
    where r_name='$r_name'
            and kit_no='$kit_no'
            and Staff_id='$Staff_id'
            and est_timek='$est_timek'
    order by check_timek desc";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {
?>
                  
                    <tr>
                        <th scope="row">Residence</th>
                        <td><?php echo $r_name;?></td>
                    </tr>

                    <tr>
                        <th scope="row">Kitchen Number</th>
                        <td><?php echo $kit_no;?></td>
                    </tr>

                    <tr>
                        <th scope="row">Inspection Time</th>
                        <td><?php echo $check_timek;?></td>
                    </tr>

                    <tr>
                        <th scope="row">Inspector</th>
                        <td><?php echo $check_staff;?></td>
                    </tr>

                    <tr>
                        <th scope="row">Microwave</th>
                        <td><?php echo $row["microwave"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Fridge</th>
                        <td><?php echo $row["fridge"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Surface</th>
                        <td><?php echo $row["surface"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Cooker</th>
                        <td><?php echo $row["cooker"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Sink</th>
                        <td><?php echo $row["sink_k"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Rubbish bin</th>
                        <td><?php echo $row["rubbish"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Wall</th>
                        <td><?php echo $row["wall_k"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Carpet</th>
                        <td><?php echo $row["carpet_k"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Other Problems</th>
                        <td><?php echo $row["set_otherk"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Result</th>
                        <td><?php echo $result_k;?></td>
                    </tr>
                  
<?php
    }
    
?>
                </tbody>
              </table>
              
              </div>
            </div>
          </div>
        </div>
      </div>
      <a href="javascript:window.print();" target="_blank" class="btn btn-outline-primary waves-effect waves-light m-1"><i class="fa fa-print"></i> Print</a>
      <a href="staff-view-record-K.php"><button type="button" class="btn btn-primary waves-effect waves-light m-1" style="float:right;">Back</button></a>
    </div>
  </div>
</div>

    
    </div><!--End content-wrapper-->

  </div>

</body>
</html>
