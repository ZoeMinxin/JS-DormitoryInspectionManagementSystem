<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      <hr>
      <div class="row">
        <div class="col-12 col-lg-4">
          <a href="staff-report-damage.php">
          <div class="card">
          <center><div class="card" style="height:50%; width:50%; border:none; margin-top:5%;;"><img src="../../images/report.png" class="card-img-top" alt="Card image cap"></div></center>
            <div class="card-body">
              <h4>Report Facility Damage</h4>
              <p>No matter when and where you see the damaged facility, please report at once!</p>
            </div>
          </div>
          </a>
        </div>
        <div class="col-12 col-lg-4">
          <a href="staff-repair-damage.php">
          <div class="card">
          <center><div class="card" style="height:50%; width:50%; border:none; margin-top:5%;;"><img src="../../images/fix.png" class="card-img-top" alt="Card image cap"></div></center>
            <div class="card-body">
              <h4>Repair Facility Damage</h4>
              <p>When the damaged facility is fixed, please let us know how everything is going!</p>
            </div>
          </div>
          </a>
        </div>
        <div class="col-12 col-lg-4">
          <a href="staff-finished-facility.php">
          <div class="card">
          <center><div class="card" style="height:50%; width:50%; border:none; margin-top:5%;;"><img src="../../images/finish.png" class="card-img-top" alt="Card image cap"></div></center>
            <div class="card-body">
              <h4>Finished Facility</h4>
              <p>Check the finishing time and other information about the facility damage!</p>
            </div>
          </div>
          </a>
        </div>

      </div>
    </div>
  </div><!--End Row-->

    </div><!--End content-wrapper-->

  </div><!--End wrapper-->
	
</body>
</html>
