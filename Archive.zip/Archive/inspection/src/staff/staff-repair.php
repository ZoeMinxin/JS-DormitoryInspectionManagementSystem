<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        
       <form action="function/staff-damage-note-func.php" method="post">
    <div class="row">
        <div class="col-lg-12">
          <div class="card">
          <div class="card-header"><h4>Damage Reports</h4></div>
            <div class="card-body">
              <div class="table-responsive">
              
               <table class="table table-striped">

                <tbody>

<?php
$r_name = $_GET['r_name'];
$damage_place = $_GET['damage_place'];
$report_time = $_GET['report_time'];
$report_id = $_GET['report_id'];

    $sql="SELECT r_name, damage_place, report_time, report_id, damage_info, status, other_info
    from damage
    where r_name='$r_name'
            and damage_place='$damage_place'
            and report_time='$report_time'
            and report_id='$report_id'";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {
?>
                  
                    <tr>
                        <th scope="row">Residence</th>
                        <td><?php echo $r_name;?></td>
                        <input type="hidden" name="r_name" value="<?php $r_name= $_GET['r_name']; echo $r_name;?>">
                    </tr>

                    <tr>
                        <th scope="row">Damage Report Place</th>
                        <td><?php echo $damage_place;?></td>
                        <input type="hidden" name="damage_place" value="<?php $damage_place= $_GET['damage_place']; echo $damage_place;?>">
                    </tr>

                    <tr>
                        <th scope="row">Report Time</th>
                        <td><?php echo $report_time;?></td>
                        <input type="hidden" name="report_time" value="<?php $report_time= $_GET['report_time']; echo $report_time;?>">
                    </tr>

                    <tr>
                        <th scope="row">Report ID</th>
                        <td><?php echo $report_id;?></td>
                        <input type="hidden" name="report_id" value="<?php $report_id= $_GET['report_id']; echo $report_id;?>">
                    </tr>

                    <tr>
                        <th scope="row">Damage Info</th>
                        <td><?php echo $row["damage_info"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Status</th>
                        <td><?php echo $row["status"]?></td>
                    </tr>
                  

                </tbody>
              </table>
              
              </div>
            </div>

            <hr/>
              <div class="card-header"><h4>Notes</h4></div><br/>
                  <div class="col-lg-12">
                    <textarea class="form-control" rows="4" id="input" name="other_info" maxlength="255" placeholder="Track Process here!" required><?php echo $row["other_info"];?></textarea>
                  </div><br/>
<?php
    }
    
?>
        <button type="submit" name="submit-in-process" class="btn btn-outline-primary waves-effect waves-light m-1 col-sm-2">In Process</button>
        <input type="hidden" name="status-in-process" value="<?php echo 'in process';?>"> <!-- in process->get status = in process; when press button in process -->

        <button type="submit" name="submit-finish" class="btn btn-outline-success waves-effect waves-light m-1 col-sm-2">Marked fixed</button>
        <input type="hidden" name="status-finish" value="<?php echo 'finish';?>">  <!-- finish->get status = finish; when press button marked fixed -->

      </form>
          </div>
        </div>
      </div>
      

  <hr/>

  <a href="staff-repair-damage.php"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
    </div>
  </div>
</div>

    
    </div><!--End content-wrapper-->
   
  </div>

  
</body>
</html>
