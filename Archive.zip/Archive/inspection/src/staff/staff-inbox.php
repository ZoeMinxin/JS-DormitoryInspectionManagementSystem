<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix"></div>
    <div class="content-wrapper">
        <div class="container-fluid">

        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <a href="staff-inbox-all.php"><button type="submit" class="btn btn-outline-primary px-5" style="float: right;">View All</button></a>    
            </div>
        </div>

        <div class="card mt-3 shadow-none">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        
                        <tbody>

<?php
    $sql="SELECT out_id, subject, content, send_time, status
    from inbox
    where in_id='$staff_id'
    order by send_time desc";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {

?>


                            <tr>
                                <td>
                                    <a href="<?php echo 'staff-reply.php?out_id='.$row['out_id'];?>+<?php echo '&subject='.$row['subject'];?>+<?php echo '&send_time='.$row['send_time'];?>+<?php echo '&content='.$row['content'];?>+<?php echo '&in_id='.$staff_id;?>"><?php echo $row["out_id"] ?></a>
                                </td>
                                <td>
                                    <a href="<?php echo 'staff-reply.php?out_id='.$row['out_id'];?>+<?php echo '&subject='.$row['subject'];?>+<?php echo '&send_time='.$row['send_time'];?>+<?php echo '&content='.$row['content'];?>+<?php echo '&in_id='.$staff_id;?>"><i class="fa fa-circle text-blue mr-2"></i><?php echo $row["subject"] ?></a>
                                </td>
                                <td class="text-right">
                                    <?php echo $row["send_time"] ?>
                                </td>
                                <td class="text-right">
                                    <?php echo $row["status"] ?>
                                </td>
                            </tr>

<?php
    } 
?>                              
                        </tbody>
                    </table>
                </div>
            </div> <!-- card body -->
        </div> <!-- card -->
 

        </div><!-- End container-fluid-->

    </div><!--End content-wrapper-->

</div><!--End wrapper-->

</body>
</html>
