<!DOCTYPE html>
<html ng-app="app" lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">SET <a href="staff-set-time-K.php" class="text-danger">KITCHEN</a> INSPECTION TIME</h4>
            </div>
        </div>

        <div class="row">
        <div class="col-lg-12">
          <div class="card">
              <div class="card-body">
                <form action="function/staff-set-time-K-func.php" name="r_nameandkit_no" method="POST">
                <div class="form-group col-md-12">
                  <label for="input-2">- Choose University Residence* -</label>
                  <div class="row">
                    <div class="col-md-4">
                    <select class="form-control" name="r_name" id="r_name" onchange="getkit_noName()">
                      <option value="0">Please select the residence</option>
                    </select>

                    </div>
                  </div>
                </div>

                  <hr/>

                  <div class="form-group col-md-4">
                    <label for="input-2">- Kitchen Number* -</label>
                    <select class="form-control" name="kit_no">
                     <option value="0">Please select the kitchen number</option>
                    </select>
                  </div>

                  <hr/>

                  <div class="form-group col-md-4">
                    <label for="input-2">- Time* -</label>
                    <input class="form-control" type="datetime-local" name="est_timek" id="est_timek" required>
                  </div>

                  <hr/>

                <div class="form-group col-md-12">
                    <button type="submit" class="btn btn-primary px-5" name="submit"><i class="icon-lock"></i> Upload</button>
                </div>
                
                </form>
              </div>
            </div>
          </div>
        </div><!-- End Row-->



    </div>
  </div><!--End Row-->

    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->

<script> //linkage radio box
var r_name = ["David Russell Apartments", "Powell Hall"];
var collect = document.getElementById("r_name")
var old = collect.innerHTML
function aa() {
    var r_nameno = " "
    for (var j = 0; j < r_name.length; j++) {
      r_nameno += '<option>' + r_name[j] + '</option>';
    }
    collect.innerHTML = old + r_nameno;
}      
aa();  
var kit_noName = [
    ["K2", "K3", "K4"],
    ["A1", "B1"]
];
 
function getkit_noName() {
    var r_nameNo = document.r_nameandkit_no.r_name;
    var kit_noNo = document.r_nameandkit_no.kit_no;
    var R_nameKit_no = kit_noName[r_nameNo.selectedIndex - 1];
    kit_noNo.length = 1;
    for (var i = 0; i < R_nameKit_no.length; i++) {
      kit_noNo[i + 1] = new Option(R_nameKit_no[i], R_nameKit_no[i]);
    }
}
</script>

<!--set date only greater than today-->
<script>
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();
var hh = today.getHours();
var min = today.getMinutes();
 /**/ if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    if(hh<10){
        hh='0'+hh
    } 
    if(min<10){
        min='0'+min
    } 

var today = yyyy+'-'+mm+'-'+dd+'T'+hh+':'+min;


document.getElementById("est_timek").min=today;

</script>

</body>
</html>