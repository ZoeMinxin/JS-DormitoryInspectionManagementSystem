<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>  <!--head (include _SESSION, DBMS connection, back to top button, core JS[does not include specific page JS] and meta/title/css links)-->

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix"></div>   <!-- staff login first enter page -->
	
  <div class="content-wrapper">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12 col-lg-4">
          <a href="staff-set-result-K.php">  <!-- quick link for staff to set record -->
          <div class="card">
            <img src="../../images/kitchen.jpg" class="card-img-top" alt="Card image cap">
            <div class="card-body">
              <h3 class="card-title">Set Inspection Record</h3>
              <h4>Kitchen</h4>
              <p>Search for the scheduled inspection kitchen and do the inspection now.</p>
            </div>
          </div>
          </a>
        </div>
        <div class="col-12 col-lg-4">
          <a href="staff-set-result-R.php">  <!-- quick link for staff to set record -->
          <div class="card">
            <img src="../../images/bedroom.jpg" class="card-img-top" alt="Card image cap">
            <div class="card-body">
              <h3 class="card-title">Set Inspection Record</h3>
              <h4>Room</h4>
              <p>Search for the scheduled inspection room and do the inspection now.</p>
            </div>
          </div>
          </a>
        </div>
        <div class="col-12 col-lg-4">
          <a href="staff-facility.php">  <!-- quick link for staff to report facility damage -->
          <div class="card">
            <img src="../../images/damage.jpg" class="card-img-top" alt="Card image cap">
            <div class="card-body">
              <h3 class="card-title">Facility Damage</h3>
              <h4>Damage Report</h4>
              <p>Read the damage report first, and then track the maintenance progress.</p>
            </div>
          </div>
          </a>
        </div>
      </div>
    </div>
  </div><!--End Row-->
  
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->

</body>
</html>
