<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix"></div>
    <div class="content-wrapper">
        <div class="container-fluid">
    
        <div class="card mt-3 shadow-none">
               <div class="card-body">
                 <form action="function/staff-reply-function.php" method="post">
                    <div class="media mb-3">
                     <div class="media-body">
                        <span class="media-meta float-right">
                            <?php
                            $send_time = $_GET['send_time'];
                            echo "$send_time";
                            ?>
                        </span>
                        <h4 class="m-0">
                            From: 
                            <?php
                            $out_id = $_GET['out_id'];
                            echo "$out_id";
                            ?>
                        </h4>
                      </div>
                    </div> <!-- media -->

                    <hr/>

                    <p>
                        <b>Subject: </b>
                        <?php
                            $subject = $_GET['subject'];
                            echo "$subject";
                        ?>
                    </p>

                    <hr/>

                    <p>
                        <b>Content: </b>
                        <?php
                            $content = $_GET['content'];
                            echo "$content";
                        ?>
                    </p>

				    <div class="form-group mt-3">
                     <textarea class="form-control" rows="9" placeholder="Reply here..." name="reply" maxlength="255" required></textarea>
					</div>

<!-- start post name but hidden in the page -->
<input type="hidden" name="out_id" value="<?php $out_id= $_GET['out_id']; echo $out_id; ?>">
<input type="hidden" name="send_time" value="<?php $send_time= $_GET['send_time']; echo $send_time; ?>">
<input type="hidden" name="subject" value="<?php $subject= $_GET['subject']; echo $subject; ?>">
<input type="hidden" name="content" value="<?php $content= $_GET['content']; echo $content; ?>">
<!-- end post name but hidden in the page -->
                  <div>
                      <button type="submit" name="submit" class="btn btn-primary waves-effect waves-light mt-3"><i class="fa fa-send mr-1"></i> Send</button>
                      <a href="staff-inbox.php"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
                  </div>
                </form>
              </div>
            </div> <!-- card -->

        </div><!-- End container-fluid-->

    </div><!--End content-wrapper-->
   
</div><!--End wrapper-->

	
</body>
</html>
