<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title"><a href="staff-set-result-R-all.php" class="text-danger">ROOM</a> INSPECTION TIME
                <a href="staff-set-result-R.php"><button type="submit" class="btn btn-outline-primary px-5" style="float: right;">MY INSPECTION</button></a>
                </h4>
            </div>
        </div>
      
    <div class="row">
        <div class="col-lg-12">
          <div class="card">
            
          <div class="card-body">
              <div class="table-responsive">
              <table id="default-datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Residence</th>
                        <th>Room</th>
                        <th>Scheduled Inspector</th>
                        <th>Scheduled Arriving Time</th>
                        <th>Set Result</th>
                        <th>Change Time</th>
                    </tr>
                </thead>


                <tbody>

<?php
    $sql="SELECT r_name, room_no, Staff_id, est_timer
    from inspection_r
    where result_r is null
    order by est_timer desc";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {
?>
                    <tr>
                        <td><?php echo $row["r_name"] ?></td>
                        <td><?php echo $row["room_no"] ?></td>
                        <td><?php echo $row["Staff_id"] ?></td>
                        <td><?php echo $row["est_timer"] ?></td>
                        <td><button type="submit" class="btn btn-primary" onclick="window.location.href='<?php echo "staff-set-r.php?r_name=".$row['r_name'];?>+<?php echo "&room_no=".$row['room_no'];?>+<?php echo "&Staff_id=".$row['Staff_id'];?>+<?php echo "&est_timer=".$row['est_timer'];?>+<?php echo "&check_staff=".$staff_id;?>'">Set Result</button></td>
                        <td><button type="submit" class="btn btn-primary" onclick="window.location.href='<?php echo "staff-edit-r.php?r_name=".$row['r_name'];?>+<?php echo "&room_no=".$row['room_no'];?>+<?php echo "&Staff_id=".$row['Staff_id'];?>+<?php echo "&est_timer=".$row['est_timer'];?>+<?php echo "&check_staff=".$staff_id;?>'">Edit</button></td>

                    </tr>
<?php
    }
?>
                </tbody>
              </table>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

    
    </div><!--End content-wrapper-->

  </div>
  
</body>
</html>
