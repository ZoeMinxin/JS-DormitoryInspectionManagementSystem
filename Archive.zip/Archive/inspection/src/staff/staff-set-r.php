<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title"><a href="staff-set-r.php" class="text-danger">ROOM</a> INSPECTION RESULT</h4>
            </div>
        </div>

        <div class="row">
        <div class="col-lg-12">
          <div class="card">
              <div class="card-body">
                
                <div class="form-group col-md-12">

<form action="function/staff-set-r-func.php" method="post">
                <div class="form-group col-md-6">
                  <label for="input-2">- University Residence -</label>
                  <input type="hidden" name="r_name" value="<?php $r_name= $_GET['r_name']; echo $r_name; ?>">
                  <div>
                    <?php
                    $r_name = $_GET['r_name'];
                    echo "<p class='mt-2'>$r_name</p>";
                    ?>
                  </div>
                  </div>                

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-2">- Room Number -</label>
                    <input type="hidden" name="room_no" value="<?php $room_no= $_GET['room_no']; echo $room_no;?>">
                    <div>
                    <?php
                    $room_no = $_GET['room_no'];
                    echo "<p class='mt-2'>$room_no</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-2">- Scheduled Inspector -</label>
                    <input type="hidden" name="Staff_id" value="<?php $Staff_id= $_GET['Staff_id']; echo $Staff_id;?>">
                    <div>
                    <?php
                    $Staff_id = $_GET['Staff_id'];
                    echo "<p class='mt-2'>$Staff_id</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-3">- Scheduled Inspection Time -</label>
                    <input type="hidden" name="est_timer" value="<?php $est_timer= $_GET['est_timer']; echo $est_timer;?>">
                    <div>
                    <?php
                    $est_timer = $_GET['est_timer'];
                    echo "<p class='mt-2'>$est_timer</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-3">- Inspector -</label>
                    <input type="hidden" name="check_staff" value="<?php $check_staff= $_GET['check_staff']; echo $check_staff;?>">
                    <div>
                    <?php
                    $check_staff = $_GET['check_staff'];
                    echo "<p class='mt-2'>$check_staff</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group col-md-8">
                            <label>SHOWER ROOM</label>
                            <select class="form-control single-select" name="shower_room">
                                <option>GOOD</option>
                                <option>NEED MORE CLEANING</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>SINK</label>
                            <select class="form-control single-select" name="sink_r">
                                <option>GOOD</option>
                                <option>NEED MORE CLEANING</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>MIRROR - BEDROOM</label>
                            <select class="form-control single-select" name="mirror_bed">
                                <option>GOOD</option>
                                <option>NEED MORE CLEANING</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>MIRROR - WASHROOM</label>
                            <select class="form-control single-select" name="mirror_wash">
                                <option>GOOD</option>
                                <option>NEED MORE CLEANING</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>TOILET</label>
                            <select class="form-control single-select" name="toilet">
                                <option>GOOD</option>
                                <option>PLEASE DEAN WITH A BRUSH</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>BIN</label>
                            <select class="form-control single-select" name="bin">
                                <option>CLEAR</option>
                                <option>PLEASE EMPTY THE BIN</option>
                            </select>
                        </div>

                    </div>

                    <div class="col-lg-6">
                        

                        <div class="form-group col-md-8">
                            <label>SAFETY NOTICE</label>
                            <select class="form-control single-select" name="safety_notice">
                                <option>EXIST</option>
                                <option>PLEASE GET A NEW ONE</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>POSTER</label>
                            <select class="form-control single-select" name="poster">
                                <option>CLEAR</option>
                                <option>PLEASE REMOVE POSTERS FROM WALLS</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>WALL</label>
                            <select class="form-control single-select" name="wall_r">
                                <option>GOOD</option>
                                <option>PLEASE WIPE WALLS</option>
                            </select>
                        </div>

                        <div class="form-group col-md-8">
                            <label>CARPET</label>
                            <select class="form-control single-select" name="carpet_r">
                                <option>GOOD</option>
                                <option>NEED MORE CLEANING</option>
                            </select>
                        </div> 

                        <div class="form-group col-md-8">
                            <label>SKIRTING</label>
                            <select class="form-control single-select" name="skirting">
                                <option>CLEAR</option>
                                <option>PLEASE WIPE SKIRTING</option>
                            </select>
                        </div> 

                        <div class="form-group col-md-8">
                            <label for="input-1">OTHER</label>
                            <input type="text" class="form-control" name="set_otherr" placeholder="Other problems">
                        </div>
                    </div>
                </div><!--End Row-->

                <hr/>

                <div class="row">
                  <div class="col-lg-6">
                    <div class="form-group col-md-8">
                      <label>RESULT</label>

                      <ul class="list" style="list-style-type:none;">
                        <li>
                          <select class="sel form-control single-select" name="result_r">
                            <option>PASS</option>
                            <option value="item1">FAIL</option>
                          </select>
                        </li>
                        <li class="item1">
                          <div class="form-group col-md-12">
                            <br/>
                            <label>- Next Inspection Time* -</label>
                            <input class="form-control" type="datetime-local" name="est_timer2" id="est_timer2">
                          </div>
                        </li>
                      </ul>

                    </div>
                  </div>
                </div>

                <hr/>

                <div class="form-group col-md-12">
                    <button type="submit" class="btn btn-primary px-5" name="submit"><i class="icon-lock"></i> Upload</button>
                    <a href="javascript:history.go(-1)"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
                </div>
                
                </form>
              </div>
            </div>
          </div>
        </div><!-- End Row-->



    </div>
  </div><!--End Row-->

    
    </div><!--End content-wrapper-->
   
  </div><!--End wrapper-->

   <!-- result->fail->set a new time for the same kitchen -->
<script type="text/javascript" src="http://libs.baidu.com/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript">
$(function(){
    $(".list .sel").change(function(event){
        $(".list li[class^=item]").hide();
        this.value.split(",").forEach(function(v){
            $(".list ."+v).show();
        });
    }).change();
});
</script>

<script>// set date only greater than today
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();
var hh = today.getHours();
var min = today.getMinutes();
 /**/ if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    if(hh<10){
        hh='0'+hh
    } 
    if(min<10){
        min='0'+min
    }
var today = yyyy+'-'+mm+'-'+dd+'T'+hh+':'+min;


document.getElementById("est_timer2").min=today;

</script>

</body>
</html>
