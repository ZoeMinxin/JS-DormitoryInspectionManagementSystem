<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">CHANGE KITCHEN INSPECTION TIME</h4>
            </div>
        </div>

        <div class="row">
        <div class="col-lg-12">
          <div class="card">
              <div class="card-body">
                
                <div class="form-group col-md-12">

<form action="function/staff-edit-k-func.php" method="post">
                <div class="form-group col-md-6">
                  <label for="input-2">- University Residence -</label>
                  <input type="hidden" name="r_name" value="<?php $r_name= $_GET['r_name']; echo $r_name; ?>">
                  <div>
                    <?php
                    $r_name = $_GET['r_name'];
                    echo "<p class='mt-2'>$r_name</p>";
                    ?>
                  </div>
                  </div>                

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-2">- Kitchen Number -</label>
                    <!--hidden post-->
                    <input type="hidden" name="kit_no" value="<?php $kit_no= $_GET['kit_no']; echo $kit_no;?>">
                    <div>
                    <?php
                    $kit_no = $_GET['kit_no'];
                    echo "<p class='mt-2'>$kit_no</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-2">- Scheduled Inspector -</label>
                    <!--hidden post-->
                    <input type="hidden" name="Staff_id" value="<?php $Staff_id= $_GET['Staff_id']; echo $Staff_id;?>">
                    <div>
                    <?php
                    $Staff_id = $_GET['Staff_id'];
                    echo "<p class='mt-2'>$Staff_id</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-2">- Original Scheduled Inspection Time -</label>
                    <input type="hidden" name="est_timek" value="<?php $est_timek= $_GET['est_timek']; echo $est_timek;?>">
                    <div>
                    <?php
                    $est_timek = $_GET['est_timek'];
                    echo "<p class='mt-2'>$est_timek</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-2">- New Scheduled Inspector -</label>
                    <input type="hidden" name="check_staff" value="<?php $check_staff= $_GET['check_staff']; echo $check_staff;?>">
                    <div>
                    <?php
                    $check_staff = $_GET['check_staff'];
                    echo "<p class='mt-2'>$check_staff</p>";
                    ?>
                    </div>
                  </div>

                  <hr/>

                  <div class="form-group col-md-6">
                    <label for="input-2">- New Scheduled Inspection Time -</label>
                    <input class="form-control" type="datetime-local" name="est_timek2" id="est_timek2" required>
                  </div>

                <hr/>

                <div class="form-group col-md-12">
                    <button type="submit" class="btn btn-primary px-5" name="submit"><i class="icon-lock"></i> Upload</button>
                    <a href="javascript:history.go(-1)"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
                </div>
                
                </form>
              </div>
            </div>
          </div>
        </div><!-- End Row-->



    </div>
  </div><!--End Row-->

    
    </div><!--End content-wrapper-->
   
  </div><!--End wrapper-->

<script>// set date only greater than today
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();
var hh = today.getHours();
var min = today.getMinutes();
 /**/ if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 
    if(hh<10){
        hh='0'+hh
    } 
    if(min<10){
        min='0'+min
    }
var today = yyyy+'-'+mm+'-'+dd+'T'+hh+':'+min;


document.getElementById("est_timek2").min=today;

</script>

</body>
</html>
