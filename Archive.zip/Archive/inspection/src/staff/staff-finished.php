<!DOCTYPE html>
<html lang="en">

<?php include '../bar/staff-head.php'; ?>

<body>

<?php include '../bar/staff-sidebar.php'; ?>  <!-- staff sidebar -->

<?php include '../bar/staff-topbar.php'; ?>  <!-- staff topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
        <div class="col-lg-12">
          <div class="card">
          <div class="card-header"><h4>Damage Report Process</h4></div>
            <div class="card-body">
              <div class="table-responsive">
               <table class="table table-striped">

                <tbody>

<?php
$r_name = $_GET['r_name'];
$damage_place = $_GET['damage_place'];
$report_time = $_GET['report_time'];
$report_id = $_GET['report_id'];

    $sql="SELECT r_name, damage_place, report_time, report_id, damage_info, other_info, finish_time
    from damage
    where r_name='$r_name'
            and damage_place='$damage_place'
            and report_time='$report_time'
            and report_id='$report_id'";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {

?>
                  
                    <tr>
                        <th scope="row">Residence</th>
                        <td><?php echo $r_name;?></td>
                    </tr>

                    <tr>
                        <th scope="row">Damage Place</th>
                        <td><?php echo $damage_place;?></td>
                    </tr>

                    <tr>
                        <th scope="row">Report Time</th>
                        <td><?php echo $report_time;?></td>
                    </tr>

                    <tr>
                        <th scope="row">Report ID</th>
                        <td><?php echo $report_id;?></td>
                    </tr>

                    <tr>
                        <th scope="row">Damage Detail</th>
                        <td><?php echo $row["damage_info"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Repair Detail</th>
                        <td><?php echo $row["other_info"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Finish Time</th>
                        <td><?php echo $row["finish_time"]?></td>
                    </tr>

<?php
    }
    
?>
                </tbody>
              </table>
              
              <hr/>
              <a href="javascript:window.print();" target="_blank" class="btn btn-outline-primary waves-effect waves-light m-1"><i class="fa fa-print"></i> Print</a>
              <a href="staff-finished-facility.php"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

    
    </div><!--End content-wrapper-->

  </div>

  
</body>
</html>
