<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
    <div class="content-wrapper">
        <div class="container-fluid">


        <div class="card mt-3 shadow-none">
               <div class="card-body">
                 <form action="function/stu-send-obj-func.php" method="post">
                    <div class="media mb-3">
                     <div class="media-body">
                        <h4 class="m-0">
                            To: 
                            <?php
                            $in_id = $_GET['in_id'];
                            echo "$in_id";
                            ?>
                        </h4>
                      </div>
                    </div> <!-- media -->

                    <hr/>

                    <p>
                        <b>Subject: </b>
                        <?php
                            $subject1 = $_GET['r_name'];
                            $subject2 = $_GET['room_no'];
                            echo "$subject1 - $subject2 - objection to room inspection result";
                        ?>
                    </p>

                    <hr/>

                    <div class="form-group">
                        <textarea class="form-control" id="summernoteEditor" maxlength="255" name="content" placeholder="Message" style="height: 200px" required></textarea>
                    </div>

                    <input type="hidden" name="in_id" value="<?php $in_id= $_GET['in_id']; echo $in_id; ?>">
                    <input type="hidden" name="subject" value="<?php $subject1 = $_GET['r_name']; $subject2 = $_GET['room_no']; echo "$subject1 - $subject2 - objection to room inspection result"; ?>">

                  <div>
                      <button type="submit" name="submit" class="btn btn-primary waves-effect waves-light mt-3"><i class="fa fa-send mr-1"></i> Reply</button>
                      <a href="student-view-record-K.php"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
                  </div>
                </form>
              </div>
            </div> <!-- card -->
    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->
	
</body>
</html>
