<!DOCTYPE html>
<html lang="en">
<head>

<?php include '../bar/student-head.php'; ?>
<link rel="stylesheet" type="text/css" href="../../css/3-level-linkage.css"> <!-- 3 level linkage-->

</head>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Report Facility Damage</h4>
            </div>
        </div>

        <div class="row">
        <div class="col-lg-12">
          <div class="card">
              <div class="card-body">
                <form action="function/student-report-damage-func.php" method="POST">

                <div class="form-group row">
                  <label for="input-6" class="col-sm-2 col-form-label">Residence</label>
                  <div class="col-sm-10">
                    <select id="residence" class="form-control single-select col-lg-12" name="r_name" onchange="Get_Next_Place('residence','Get_place')">
                        <option id="Not_data1">CHOOSE RESIDENCE</option>
                        <option id="David Russell Apartments" value="David Russell Apartments">David Russell Apartments</option>
                        <option id="Powell Hall" value="Powell Hall">Powell Hall</option>
                    </select>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-6" class="col-sm-2 col-form-label">Room Type</label>
                  <div class="col-sm-10">
                    <select id="place" class="form-control single-select col-lg-12" onchange="Get_Next_Place('place','Get_number')">
                        <option id="Not_data2">CHOOSE ROOM TYPE</option>
                    </select>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-6" class="col-sm-2 col-form-label">Room</label>
                  <div class="col-sm-10">
                    <select id="number" class="form-control single-select col-lg-12" name="damage_place">
                        <option id="Not_data3">CHOOSE ROOM</option>
                    </select>
                  </div>
                </div>

                  <div class="form-group row">
                  <label for="input-9" class="col-sm-2 col-form-label">Damage Report</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" rows="4" id="input-9" name="damage_info" required></textarea>
                  </div>
                </div>
                 

                <div class="form-group col-md-12">
                    <button type="submit" class="btn btn-primary px-5" name="submit"><i class="icon-lock"></i> Upload</button>
                    <a href="student-facility.php"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
                </div>
                
                </form>
              </div>
            </div>
          </div>
        </div><!-- End Row-->



    </div>
  </div><!--End Row-->

    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->

  <script src="../../js/3-level-linkage.js"></script> <!-- 3 level linkage (residence->room type->room)-->

</body>
</html>
