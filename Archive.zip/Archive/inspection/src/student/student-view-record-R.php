<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      
    <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Room Inspection Result</h4>
            </div>
        </div>

    <div class="row">
        <div class="col-lg-12">
          <div class="card">
            
            <div class="card-body">
              <div class="table-responsive">
              <table id="default-datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Residence</th>
                        <th>Room</th>
                        <th>Inspection Time</th>
                        <th>Result</th>
                        <th>Details</th>
                        <th>Talk to Inspector</th>
                    </tr>
                </thead>


                <tbody>

<?php
    $sql="SELECT r_name, room_no, est_timer, check_timer, check_staff, result_r
    from inspection_r
    where (r_name, room_no) in
        (select r_name, room_no
        from occupied
        where stu_id='$stu_id')
    and result_r is not null
    order by est_timer desc";

    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {
?>
                  
                    <tr> 
                        <td><?php echo $row["r_name"] ?></td>
                        <td><?php echo $row["room_no"] ?></td>
                        <td><?php echo $row["check_timer"] ?></td> 
                        <td><?php echo $row["result_r"] ?></td>    
                        <td><button type="submit" class="btn btn-primary" onclick="window.location.href='<?php echo "student-view-r.php?r_name=".$row['r_name'];?>+<?php echo "&room_no=".$row['room_no'];?>+<?php echo "&est_timer=".$row['est_timer'];?>'">View Details</button></td>                
                        <td><button type="submit" class="btn btn-primary" onclick="window.location.href='<?php echo "student-send-obj-r.php?r_name=".$row['r_name'];?>+<?php echo "&room_no=".$row['room_no'];?>+<?php echo "&in_id=".$row['check_staff'];?>'">Objection</button></td>
                    </tr>
                  
<?php
    }
    
?>
                </tbody>
              </table>
              </div>
            </div>
          </div>
        </div>
      </div>

    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->
	
</body>
</html>
