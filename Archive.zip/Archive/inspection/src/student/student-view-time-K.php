<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      
    <div class="row">
        <div class="col-lg-12">
          <div class="card">
            
            <div class="card-body">
              <div class="table-responsive">
              <table id="default-datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Residence</th>
                        <th>Kitchen</th>
                        <th>Scheduled Arriving Time</th>
                        <th>Change Time</th>
                        <th>Download Outlook Calendar</th>
                    </tr>
                </thead>


                <tbody>

<?php
    $sql="SELECT r_name, kit_no, Staff_id, est_timek
    from inspection_k
    where (r_name, kit_no) in
        (select r_name, kit_no
        from occupies
        where stu_id='$stu_id')
    and result_k is null
    order by est_timek";

    $result = mysqli_query($conn, $sql);

    
    while ($row = mysqli_fetch_array ($result))
    {
?>
                  
                    <tr> 
                        <td><?php echo $row["r_name"] ?></td>
                        <td><?php echo $row["kit_no"] ?></td>
                        <td><?php echo $row["est_timek"] ?></td>  
                        <td><button type="submit" class="btn btn-primary" onclick="window.location.href='<?php echo "stu-change-time-k.php?r_name=".$row['r_name'];?>+<?php echo "&kit_no=".$row['kit_no'];?>+<?php echo "&Staff_id=".$row['Staff_id'];?>'">Request New Time</button></td>
                        <td><a href="ical.php?date=<?php echo substr($row['est_timek'],0,4);echo substr($row['est_timek'],5,2);echo substr($row['est_timek'],8,2);?>&amp;startTime=<?php echo substr($row['est_timek'],11,2);echo substr($row['est_timek'],14,2);?>&amp;endTime=<?php echo substr($row['est_timek'],11,2);echo substr($row['est_timek'],14,2)+1;?>&amp;subject=Inspection&amp;desc=Kitchen inspection."><button type="submit" class="btn btn-primary">Download</button></a></td>                   
                    </tr>

<?php
    }
    
?>
                </tbody>
              </table>
              </div>
            </div>
          </div>
        </div>
      </div>

    
    </div><!--End content-wrapper-->
   
  </div><!--End wrapper-->

</body>
</html>
