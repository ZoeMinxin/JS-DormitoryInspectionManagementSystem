<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix">
	
  <div class="content-wrapper">
    <div class="container-fluid">
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">DAMAGE REPORT STATUS</h4>
            </div>
        </div>
      
    <div class="row">
        <div class="col-lg-12">
          <div class="card">
            
            <div class="card-body">
              <div class="table-responsive">
              <table id="default-datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Residence</th>
                        <th>Damage Place</th>
                        <th>Damage Information</th>
                        <th>Status</th>                       
                        <th>Finish Time</th>
                    </tr>
                </thead>


                <tbody>

<?php
    $sql="SELECT r_name, damage_place, report_time, damage_info, finish_time, status
    from damage
    where report_id='$stu_id'";


    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {
?>
                  
                    <tr>
                     
                        <td><?php echo $row["r_name"] ?></td>
                        <td><?php echo $row["damage_place"] ?></td>
                        <td><?php echo $row["damage_info"] ?></td>
                        <td><?php echo $row["status"] ?></td>                       
                        <td><?php echo $row["finish_time"] ?></td>
     
                    </tr>
                  
<?php
    }
    
?>
                </tbody>
              </table>
              <hr/>
              <div class="form-group col-md-12">
                    <a href="student-facility.php"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

    
    </div><!--End content-wrapper-->
   
  </div><!--End wrapper-->

</body>
</html>
