<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
    <div class="content-wrapper">
        <div class="container-fluid">

        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <a href="stu-send.php"><button type="submit" class="btn btn-outline-primary px-5" style="float: right;">Talk to your dormitory staff here!</button></a>    
            </div>
        </div>


        <div class="card mt-3 shadow-none">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        
                        <tbody>

<?php
    $sql="SELECT out_id, in_id, subject, content, send_time, reply_time, status, reply
    from inbox
    where out_id='$stu_id'
    and status='read'
    order by send_time desc";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {

?>

                            <tr>
                                <td>
                                    <a href="<?php echo 'stu-reply.php?out_id='.$row['out_id'];?>+<?php echo '&subject='.$row['subject'];?>+<?php echo '&reply_time='.$row['reply_time'];?>+<?php echo '&content='.$row['content'];?>+<?php echo '&in_id='.$row['in_id'];?>+<?php echo '&reply='.$row['reply'];?>"><?php echo $row["in_id"] ?></a>
                                </td>
                                <td>
                                    <a href="<?php echo 'stu-reply.php?out_id='.$row['out_id'];?>+<?php echo '&subject='.$row['subject'];?>+<?php echo '&reply_time='.$row['reply_time'];?>+<?php echo '&content='.$row['content'];?>+<?php echo '&in_id='.$row['in_id'];?>+<?php echo '&reply='.$row['reply'];?>"><i class="fa fa-circle text-blue mr-2"></i>Reply: <?php echo $row["subject"] ?></a>
                                </td>
                                <td class="text-right">
                                    <?php echo $row["reply_time"] ?>
                                </td>
                            </tr>

<?php
    } 
?>                             
                        </tbody>
                    </table>
                </div>
            </div> <!-- card body -->
        </div> <!-- card -->

    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->
	
</body>
</html>
