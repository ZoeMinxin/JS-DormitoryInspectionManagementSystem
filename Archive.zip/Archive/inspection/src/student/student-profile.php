<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
    <div class="content-wrapper">
        <div class="container-fluid">
<div class="row"><!--Start Row-->
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="card-title">My Profile</div>
                <hr>
                <form>
                    <div class="form-group">
                        <label for="input-1">Student ID</label>
                        <?php
                            echo "<p>&nbsp; $stu_id</p>";
                        ?>
                    </div>
                    <hr/>
                    <div class="form-group">
                        <label for="input-2">Name</label>
                        <?php
                            echo "<p>&nbsp; $stu_name</p>";
                        ?>
                    </div>
                    <hr/>
                    <div class="form-group">
                        <label for="input-3">Email</label>
                        <?php
                            echo "<p>&nbsp; $stu_email</p>";
                        ?>
                    </div>
                    <hr/>
                </form>
                </div>
        </div>
    </div>

</div><!--End Row-->

<div class="card">
  <div class="card-body">
    <div class="row">
                
    <div class="col-lg-4">
      <button class="btn btn-primary btn-block m-1" data-toggle="modal" data-target="#formemodal1">CHANGE PASSWORD</button>
      <button class="btn btn-outline-primary btn-block mt-4 ml-1" data-toggle="modal" data-target="#formemodal2">CHANGE EMAIL ADDRESS</button>
    </div>

      <div class="modal fade" id="formemodal1"><!-- Modal pwd -->
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Change Password Here!</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form action="function/student-change-pwd.php" method="post">
                <div class="form-group">
                  <label for="input-1">Original Password</label>
                  <input type="password" name="stu_pwd" class="form-control" id="pw3" placeholder="Enter Your Original Password" required>
                </div>
                <div class="form-group">
                  <label for="input-2">New Password</label>
                  <input type="password" name="stu_pwd2" class="form-control" id="pw1" placeholder="Enter Your New Password" onkeyup="oandn()" required>
                </div>
                <span id="tipchange"></span>
                <div class="form-group">
                  <label for="input-3">Confirm New Password</label>
                  <input type="password" name="pwd" class="form-control" id="pw2" placeholder="Confirm Your New Password" onkeyup="validate()" required>
                </div>
                <span id="tip"></span>
                <div class="form-group">
                  <button type="submit" class="btn btn-primary px-5" name="submit"><i class="icon-lock"></i> Change Now</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" id="formemodal2"><!-- Modal email -->
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Change Email Address Here!</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form action="function/student-change-email.php" method="post">
                <div class="form-group">
                  <label for="input-1">Original Email Address</label>
                  <input type="email" name="stu_email" class="form-control" id="em3" placeholder="Enter Your Original Email" required>
                </div>
                <div class="form-group">
                  <label for="input-2">New Email Address</label>
                  <input type="email" name="stu_email2" class="form-control" id="em1" placeholder="Enter Your New Email" onkeyup="eoandn()" required>
                </div>
                <span id="etipchange"></span>
                <div class="form-group">
                  <button type="submit" class="btn btn-primary px-5" name="submit"><i class="icon-lock"></i> Change Now</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      </div>
    </div>
  </div>
</div>

</div><!-- End container-fluid-->

    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->

  <!-- check original and new password & email -->
  <script src="../../js/changepwd&email.js"></script>

</body>
</html>
