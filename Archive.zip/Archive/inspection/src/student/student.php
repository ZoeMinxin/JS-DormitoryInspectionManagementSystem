<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>  <!--head (include _SESSION, DBMS connection, back to top button, core JS[does not include specific page JS] and meta/title/css links)-->

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      <hr>
      <div class="row">
        <div class="col-12 col-lg-4">
          <a href="student-movein.php">
          <div class="card">
            <img src="../../images/movein.jpg" class="card-img-top" alt="Card image cap">
            <div class="card-body">
              <h3 class="card-title">Where are you living?</h3>
              <h4>Move in</h4>
              <p>If it is the first time you come to the University residence, please register your room and kitchen here!</p>
            </div>
          </div>
          </a>
        </div>
        <div class="col-12 col-lg-4">
          <a href="student-moveout.php">
          <div class="card">
            <img src="../../images/moveout.jpg" class="card-img-top" alt="Card image cap">
            <div class="card-body">
              <h3 class="card-title">Want to move out?</h3>
              <h4>Move out</h4>
              <p>If it is the last day you live in the dormitory, please register to move out here!</p>
            </div>
          </div>
          </a>
        </div>
        <div class="col-12 col-lg-4">
          <a href="student-facility.php">
          <div class="card">
            <img src="../../images/damage.jpg" class="card-img-top" alt="Card image cap">
            <div class="card-body">
              <h3 class="card-title">Facility Damage</h3>
              <h4>Damage Report</h4>
              <p>If you see any damaged facility around you, please report here immediately! We appreciate your reminder!</p>
            </div>
          </div>
          </a>
        </div>
      </div>
    </div>
  </div><!--End Row-->

    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->
	
</body>
</html>
