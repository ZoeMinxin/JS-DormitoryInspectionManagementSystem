<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
    <div class="content-wrapper">
        <div class="container-fluid">

        <div class="col-lg-12 col-md-8">
            
            <div class="card mt-3 shadow-none">
                <div class="card-body">
                    <form action="function/stu-send-func.php" method=post>
                        <div class="form-group">
                            <div class="demo-heading">To: All Staff</div> 
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Subject" maxlength="100" name="subject" required>
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" id="summernoteEditor" maxlength="255" name="content" placeholder="Message" style="height: 200px" required></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" name="submit" class="btn btn-primary waves-effect waves-light m-1"><i class="fa fa-send mr-1"></i> Send</button>
                            <a href="stu-send.php"><button type="button" class="btn btn-white waves-effect waves-light m-1"><i class="fa fa-trash-o mr-1"></i> <span>Discard</span> </button></a>
                            <a href="student-inbox.php"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
                        </div>
                    </form>
                </div> <!-- card body -->
            </div> <!-- card -->
        </div> <!-- end Col-9 -->
    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->
	
</body>
</html>
