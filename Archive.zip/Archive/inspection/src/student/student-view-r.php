<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      
    <div class="row">
        <div class="col-lg-12">
          <div class="card">
          <div class="card-header"><h4>Room Inspection Result</h4></div>
            <div class="card-body">
              <div class="table-responsive">
               <table class="table table-striped">

                <tbody>

<?php
$r_name = $_GET['r_name'];
$room_no = $_GET['room_no'];
$est_timer = $_GET['est_timer'];

    $sql="SELECT r_name, room_no, est_timer, shower_room, sink_r, mirror_bed, mirror_wash, toilet, bin, safety_notice, poster, wall_r, carpet_r, skirting, set_otherr, check_timer, result_r
    from inspection_r
    where r_name='$r_name'
            and room_no='$room_no'
            and est_timer='$est_timer'";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {
?>
                  
                    <tr>
                        <th scope="row">Residence</th>
                        <td><?php echo $r_name;?></td>
                    </tr>

                    <tr>
                        <th scope="row">Room Number</th>
                        <td><?php echo $row["room_no"];?></td>
                    </tr>

                    <tr>
                        <th scope="row">Inspection Time</th>
                        <td><?php echo $row["check_timer"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Shower Room</th>
                        <td><?php echo $row["shower_room"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Sink</th>
                        <td><?php echo $row["sink_r"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Bedroom Mirror</th>
                        <td><?php echo $row["mirror_bed"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Washroom Mirror</th>
                        <td><?php echo $row["mirror_wash"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Toilet</th>
                        <td><?php echo $row["toilet"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Rubbish bin</th>
                        <td><?php echo $row["bin"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Safety Notice</th>
                        <td><?php echo $row["safety_notice"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Poster</th>
                        <td><?php echo $row["poster"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Wall</th>
                        <td><?php echo $row["wall_r"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Carpet</th>
                        <td><?php echo $row["carpet_r"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Skirting</th>
                        <td><?php echo $row["skirting"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Other Problems</th>
                        <td><?php echo $row["set_otherr"]?></td>
                    </tr>

                    <tr>
                        <th scope="row">Result</th>
                        <td><?php echo $row["result_r"]?></td>
                    </tr>
                  
<?php
    }
    
?>
                </tbody>
              </table>
              
              </div>
            </div>
          </div>
        </div>
      </div>
      <a href="javascript:window.print();" target="_blank" class="btn btn-outline-primary waves-effect waves-light m-1"><i class="fa fa-print"></i> Print</a>
      <a href="student-view-record-R.php"><button type="button" class="btn btn-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
    </div>
  </div>
</div>

    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->

</body>
</html>
