<!DOCTYPE html>
<html lang="en">
<head>

<?php include '../bar/student-head.php'; ?>
<link rel="stylesheet" type="text/css" href="../../css/3-level-linkage.css"> <!-- 3 level linkage-->

</head>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      
      <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Move In</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
          <div class="card">
              <div class="card-body">
                <form action="function/student-movein-func.php" method="POST">

                <div class="form-group row">
                  <label for="input-6" class="col-sm-2 col-form-label">Residence</label>
                  <div class="col-sm-10">
                    <select id="residence" class="form-control single-select col-lg-12" name="r_name" onchange="Get_Next_Kit('residence','Get_kit')">
                        <option id="Not_data1">Choose Residence</option>
                        <option id="David Russell Apartments" value="David Russell Apartments">David Russell Apartments</option>
                        <option id="Powell Hall" value="Powell Hall">Powell Hall</option>
                    </select>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-6" class="col-sm-2 col-form-label">Kitchen</label>
                  <div class="col-sm-10">
                    <select id="kit" class="form-control single-select col-lg-12" name="kit_no" onchange="Get_Next_Kit('kit','Get_room')">
                        <option id="Not_data2">Choose Kitchen</option>
                    </select>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-6" class="col-sm-2 col-form-label">Room</label>
                  <div class="col-sm-10">
                    <select id="room" class="form-control single-select col-lg-12" name="room_no">
                        <option id="Not_data3">Choose Room</option>
                    </select>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-9" class="col-sm-2 col-form-label">Move In Date</label>
                  <div class="col-sm-10">
                  <input class="form-control" type="date" name="move_in_date">
                  </div>
                </div>
                 

                <div class="form-group col-md-12">
                    <button type="submit" class="btn btn-primary px-5" name="submit"><i class="icon-lock"></i> Upload</button>
                    <a href="javascript:history.go(-1)"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
                </div>
                
                </form>
              </div>
            </div>
          </div>
        </div><!-- End Row-->


    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->

  <script src="../../js/student-movein.js"></script>  <!--3-level selection-->

</body>
</html>
