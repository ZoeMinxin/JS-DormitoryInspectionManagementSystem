<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      
      <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Move Out</h4>
            </div>
        </div>
    </div>

    <div class="row"><!--Start Row-->
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <form action="function/student-moveout-func.php" method="POST">

<?php

    $sql="SELECT r_name, kit_no, room_no, stu_id, move_in_date
    from occupies
    where stu_id='$stu_id'";
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_array ($result))
    {
?>

                        <div class="form-group">
                            <label for="input-1">Student ID</label>
                            <?php
                                echo "<p>&nbsp; $stu_id</p>";
                            ?>
                        </div>

                        <hr/>

                        <div class="form-group">
                            <label for="input-2">Name</label>
                            <?php
                                echo "<p>&nbsp; $stu_name</p>";
                            ?>
                        </div>

                        <hr/>

                        <div class="form-group">
                            <label for="input-2">Residence</label>
                            <p>&nbsp; 
                            <?php
                                echo $row["r_name"];
                            ?>
                            </p>
                            <input type="hidden" name="r_name" value="<?php echo $row['r_name'];?>">
                        </div>

                        <hr/>

                        <div class="form-group">
                            <label for="input-3">Kitchen Number</label>
                            <p>&nbsp; 
                            <?php
                                echo $row["kit_no"];
                            ?>
                            </p>
                            <input type="hidden" name="kit_no" value="<?php echo $row['kit_no'];?>">
                        </div>

                        <hr/>

                        <div class="form-group">
                            <label for="input-3">Room Number</label>
                            <p>&nbsp; 
                            <?php
                                echo $row["room_no"];
                            ?>
                            </p>
                            <input type="hidden" name="room_no" value="<?php echo $row['room_no'];?>">
                        </div>

                        <hr/>

                        <div class="form-group">
                            <label for="input-3">Move In Date</label>
                            <p>&nbsp; 
                            <?php
                                echo $row["move_in_date"];
                            ?>
                            </p>
                            <input type="hidden" name="move_in_date" value="<?php echo $row['move_in_date'];?>">
                        </div>

                        <hr/>

                        <div class="form-group">
                            <label for="input-3">Move Out Date</label>
                            <div class="col-sm-12">
                                <input class="form-control" type="date" name="move_out_date">
                            </div>
                        </div>

<?php
    }
?>

                <div class="form-group col-md-12">
                    <button type="submit" class="btn btn-primary px-5" name="submit"><i class="icon-lock"></i> Upload</button>
                    <a href="javascript:history.go(-1)"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
                </div>

                    </form>
                </div>
            </div>
        </div>

    </div><!--End Row-->


    
    </div><!--End content-wrapper-->
   
  </div><!--End wrapper-->
   

</body>
</html>
