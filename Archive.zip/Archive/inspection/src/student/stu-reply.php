<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
    <div class="content-wrapper">
        <div class="container-fluid">

        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <a href="stu-send.php"><button type="submit" class="btn btn-outline-primary px-5" style="float: right;">Talk to your dormitory staff here!</button></a>    
            </div>
        </div>

        <div class="card mt-3 shadow-none">
               <div class="card-body">
                 <form action="stu-reply-content.php" method="get">
                    <div class="media mb-3">
                     <div class="media-body">
                        <span class="media-meta float-right">
                            <?php
                            $reply_time = $_GET['reply_time'];
                            echo "$reply_time";
                            ?>
                        </span>
                        <h4 class="m-0">
                            From: 
                            <?php
                            $in_id = $_GET['in_id'];
                            echo "$in_id";
                            ?>
                        </h4>
                      </div>
                    </div> <!-- media -->

                    <hr/>

                    <p>
                        <b>Subject: </b>
                        <?php
                            $subject = $_GET['subject'];
                            echo "$subject";
                        ?>
                    </p>

                    <hr/>

                    <p>
                        <b>Content: </b>
                        <?php
                            $content = $_GET['content'];
                            echo "$content";
                        ?>
                    </p>

                    <hr/>

                    <p>
                        <b>Reply: </b>
                        <?php
                            $reply = $_GET['reply'];
                            echo "$reply";
                        ?>
                    </p>

                    <input type="hidden" name="in_id" value="<?php $in_id= $_GET['in_id']; echo $in_id; ?>">
                    <input type="hidden" name="subject" value="<?php $subject= $_GET['subject']; echo $subject; ?>">
                    <input type="hidden" name="content" value="<?php $content= $_GET['content']; echo $content; ?>">
                    <input type="hidden" name="reply" value="<?php $reply= $_GET['reply']; echo $reply; ?>">
                    <input type="hidden" name="reply_time" value="<?php $reply_time= $_GET['reply_time']; echo $reply_time; ?>">

                  <div>
                      <button type="submit" name="submit" class="btn btn-primary waves-effect waves-light mt-3"><i class="fa fa-send mr-1"></i> Reply</button>
                      <a href="student-inbox.php"><button type="button" class="btn btn-outline-primary waves-effect waves-light m-1" style="float: right;">Back</button></a>
                  </div>
                </form>
              </div>
            </div> <!-- card -->
    
    </div><!--End content-wrapper-->

  </div><!--End wrapper-->

	
</body>
</html>
