<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

session_start();
$stu_id=$_SESSION["Stu_id"];

include ('../../bar/connect.php');
$conn = OpenCon();

$r_name = $_POST['r_name'];
$kit_no = $_POST['kit_no'];
$room_no = $_POST['room_no'];
$move_in_date = $_POST['move_in_date'];

$exist="select stu_id 
        from occupies 
        where stu_id='$stu_id'";

$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if(!$erow)
{
    $qu1 = "INSERT INTO occupies (r_name,kit_no,room_no,stu_id,move_in_date)
    VALUES ('$r_name', '$kit_no','$room_no','$stu_id','$move_in_date')";

    $qu2 = "INSERT INTO occupied (r_name,kit_no,room_no,stu_id,move_in_date)
    VALUES ('$r_name', '$kit_no','$room_no','$stu_id','$move_in_date')";

    $result1 = mysqli_query($conn, $qu1);
    $result2 = mysqli_query($conn, $qu2);
    
    if(!$result1 && !$result2){
        echo "
        <script>
            setTimeout(function(){window.location.href='../student-movein.php';},2000);
        </script>
        ";
    
    }
    else{
        echo "Insert move in date successfully! Please login again!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../student-login.html';},2000);
            </script>
            ";
    
    
    }
   
}
else
{

    $quu1 = "UPDATE occupies
        SET r_name='$r_name',kit_no='$kit_no',room_no='$room_no',stu_id='$stu_id',move_in_date='$move_in_date'
        WHERE stu_id='$stu_id'";

    $quu2 = "INSERT INTO occupied (r_name,kit_no,room_no,stu_id,move_in_date)
    VALUES ('$r_name', '$kit_no','$room_no','$stu_id','$move_in_date')";

    $resultu1 = mysqli_query($conn, $quu1);
    $resultu2 = mysqli_query($conn, $quu2);
    
    if(!$resultu1 && !$resultu2){
        echo "
        <script>
            setTimeout(function(){window.location.href='../student-movein.php';},2000);
        </script>
        ";
    
    }
    else{
        echo "Change your room successfully! Please login again!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../student-login.html';},2000);
            </script>
            ";
    
    
    }

}







mysqli_close($conn);


?>