<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

$report_time = date('Y-m-d H:i:s');;// submit button clicking time

session_start();
$report_id=$_SESSION["Stu_id"];

include ('../../bar/connect.php');
$conn = OpenCon();

$r_name = $_POST['r_name'];
$damage_place = $_POST['damage_place'];
$damage_info = $_POST['damage_info'];

$exist="select r_name,damage_place,report_time,report_id
        from damage 
        where r_name='$r_name'
        and damage_place='$damage_place'
        and report_time='$report_time'
        and report_id='$report_id'";

$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if(!$erow)
{
    $qu = "INSERT INTO damage (r_name,damage_place,report_time,report_id,damage_info,status)
    VALUES ('$r_name', '$damage_place','$report_time','$report_id',replace(replace('$damage_info',char(10),' '),char(13),' '),'unread')";
    $result = mysqli_query($conn, $qu);
    
    if(!$result){
        echo "Please insert all information!";
        echo "
        <script>
            setTimeout(function(){window.location.href='../damage-reports.php';},2000);
        </script>
        ";
    
    }
    else{
        echo "Insert damage report successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../student-facility.php';},2000);
            </script>
            ";
    
    
    }
   
}
else
{

    echo "The damage has been reported already!";
    echo "
        <script>
            setTimeout(function(){window.location.href='../staff-facility.php';},2000);
        </script>
        ";
}







mysqli_close($conn);


?>