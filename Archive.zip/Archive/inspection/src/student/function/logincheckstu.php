<?php

session_start();

if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //check if "submit" acted 

include ('../../bar/connect.php');
$conn = OpenCon();

$Stu_id=$_POST['Stu_id'];
$Stu_pwd=$_POST['Stu_pwd'];


if($Stu_id && $Stu_pwd){
    $checkstu = "SELECT * FROM student WHERE stu_id='$Stu_id' and stu_pwd='$Stu_pwd'";
    $result = mysqli_query($conn, $checkstu);
    $rows=mysqli_num_rows($result);
    if($rows){
        header("refresh:0; url= ../student.php");
        $_SESSION["Stu_id"]=$Stu_id;                          //store id

        $findname=" select * from student where stu_id='$Stu_id'";
        $nameresult = mysqli_query ($conn, $findname);

        while ($rowstuname =mysqli_fetch_array($nameresult))
        {
            $_SESSION["Stu_name"] = $rowstuname['stu_name'];    //store name
        }                                                   

        $findemail=" select * from student where stu_id='$Stu_id'";
        $emailresult = mysqli_query ($conn, $findemail);
       
        while ($rowstuemail =mysqli_fetch_array($emailresult))
        {
            $_SESSION["Stu_email"] = $rowstuemail['stu_email'];      //store email
        }       

        exit;
    }

    else{
        echo "Wrong student ID or Password";
        echo "
        <script>
            setTimeout(function(){window.location.href='../student-login.html';},2000);
        </script>
        ";
    }
}
else{
    echo "Please complete your student ID and password";
    echo "
        <script>
            setTimeout(function(){window.location.href='../student-login.html';},2000);
        </script>
        ";

}


mysqli_close($conn);


?>