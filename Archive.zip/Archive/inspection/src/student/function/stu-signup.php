<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

include ('../../bar/connect.php');
$conn = OpenCon();

$Stu_id = $_POST['Stu_id'];
$Stu_name = $_POST['Stu_name'];
$Stu_email = $_POST['Stu_email'];
$Stu_pwd = $_POST['Stu_pwd'];

$exist="select stu_id from student where stu_id='$Stu_id'";
$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if(!$erow)
{
  if(strlen($Stu_id) == 6){
    $qu = "INSERT INTO student VALUES ('$Stu_id', '$Stu_name','$Stu_email','$Stu_pwd')";
    $result = mysqli_query($conn, $qu);
    
    if(!$result){
        echo "
        <script>
            setTimeout(function(){window.location.href='../student-login.html';},2500);
        </script>
        ";
    
    }
    else{
        echo "Sign up successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../student-login.html';},2500);
            </script>
            ";
    
    
    }
  } else {
    echo "Your ID is not a 6-digit number! Please check your Student ID again!";
    echo "
        <script>
            setTimeout(function(){window.location.href='../student-signup.html';},3000);
        </script>
        ";
  }
   
}
else
{

    echo "Your ID has been signed up already!";
    echo "
        <script>
            setTimeout(function(){window.location.href='../student-login.html';},2500);
        </script>
        ";
}







mysqli_close($conn);


?>