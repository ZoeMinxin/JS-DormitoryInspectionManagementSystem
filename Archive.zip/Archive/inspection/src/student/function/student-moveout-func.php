<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

session_start();
$stu_id=$_SESSION["Stu_id"];

include ('../../bar/connect.php');
$conn = OpenCon();

$r_name = $_POST['r_name'];
$kit_no = $_POST['kit_no'];
$room_no = $_POST['room_no'];
$move_in_date = $_POST['move_in_date'];
$move_out_date = $_POST['move_out_date'];

$exist="select stu_id 
        from occupies 
        where stu_id='$stu_id'";

$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if(!$erow)
{

        echo "You haven't register your move in information!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../student-movein.php';},2000);
            </script>
            ";

   
}
else
{

    $qu = "UPDATE occupied
        SET move_out_date='$move_out_date'
        WHERE stu_id='$stu_id'
        AND r_name='$r_name'
        AND kit_no='$kit_no'
        AND room_no='$room_no'
        AND move_in_date='$move_in_date'";

    $result = mysqli_query($conn, $qu);
    
    if(!$result){
        echo "
        <script>
            setTimeout(function(){window.location.href='../student-movein.php';},2000);
        </script>
        ";
    
    }
    else{
        echo "You have rigistered your move out date successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../student.php';},2000);
            </script>
            ";
    
    
    }

}







mysqli_close($conn);


?>