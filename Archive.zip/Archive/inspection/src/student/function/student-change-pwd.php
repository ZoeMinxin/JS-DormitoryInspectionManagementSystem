<?php

// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

session_start();
$stu_id=$_SESSION["Stu_id"];

include ('../../bar/connect.php');
$conn = OpenCon();

$stu_pwd = $_POST['stu_pwd'];
$stu_pwd2 = $_POST['stu_pwd2'];
$stu_pwdcheck = "select stu_pwd from student where stu_id='$stu_id'";

$ere=mysqli_query($conn, $stu_pwdcheck);
$pwdcheck = mysqli_fetch_array($ere);

if(! $ere){
    die("Could not connect: " . mysql_error($conn));
}
else{
    if($stu_pwd == $pwdcheck['stu_pwd']){
        $sql = "UPDATE student
            SET stu_pwd = '$stu_pwd2'
            WHERE stu_id = '$stu_id'
            ";

        $result = mysqli_query($conn, $sql);


        if(!$result){
            echo "
            <script>
                setTimeout(function(){window.location.href='../student-profile.php';},2000);
            </script>
            ";
    
        }
        else{
       
        echo "Updated new password successfully.\n Please login with new password again!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../student-login.html';},2000);
            </script>
            ";
        }
    }

    else{
        echo "Your original passwords don't match.";
        echo "
            <script>
                setTimeout(function(){window.location.href='../student-profile.php';},2000);
            </script>
            ";
    }
}





mysqli_close($conn);


?>