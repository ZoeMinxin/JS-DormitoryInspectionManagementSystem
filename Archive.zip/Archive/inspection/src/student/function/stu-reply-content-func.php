<?php
// header("Content-Type: text-html; charset=utf-8");
if (!isset($_POST["submit"])){
    exit("Wrong Action");
} //cheching if "submit" acted 

$send_time = date('Y-m-d H:i:s');;// submit button clicking time

session_start();
$out_id=$_SESSION["Stu_id"];

include ('../../bar/connect.php');
$conn = OpenCon();

$subject = $_POST['subject'];
$content = $_POST['content'];
$in_id = $_POST['in_id'];

$exist="select out_id,send_time,subject,content
        from inbox 
        where out_id='$out_id'
        and send_time='$send_time'
        and subject='$subject'
        and content='$content'";

$ere=mysqli_query($conn, $exist);
$erow=mysqli_num_rows($ere);
if(!$erow)
{
    $qu = "INSERT INTO inbox (out_id,in_id,send_time,subject,content,status)
    VALUES ('$out_id', '$in_id', '$send_time','$subject',replace(replace('$content',char(10),' '),char(13),' '),'unread')";
    $result = mysqli_query($conn, $qu);
    
    if(!$result){
        echo "Please insert all information!";
        echo "
        <script>
            setTimeout(function(){window.location.href='../stu-send.php';},2000);
        </script>
        ";
    
    }
    else{
        echo "Send successfully!";
        echo "
            <script>
                setTimeout(function(){window.location.href='../student-inbox.php';},2000);
            </script>
            ";
    
    
    }
   
}
else
{

    echo "The information has been sent already!";
    echo "
        <script>
            setTimeout(function(){window.location.href='../stu-send.php';},2000);
        </script>
        ";
}







mysqli_close($conn);


?>