<!DOCTYPE html>
<html lang="en">

<?php include '../bar/student-head.php'; ?>

<body>

<?php include '../bar/student-sidebar.php'; ?>  <!-- student sidebar -->

<?php include '../bar/student-topbar.php'; ?>  <!-- student topbar -->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      <hr>
      <div class="row">
        <div class="col-12 col-lg-6">
          <a href="student-report-damage.php">
          <div class="card">
          <center><div class="card" style="height:50%; width:50%; border:none; margin-top:5%;;"><img src="../../images/report.png" class="card-img-top" alt="Card image cap"></div></center>
            <div class="card-body">
              <h4>Report Facility Damage</h4>
              <p>No matter when and where you see the damaged facility, please report to us without hesitation!</p>
            </div>
          </div>
          </a>
        </div>

        <div class="col-12 col-lg-6">
          <a href="student-view-damage-status.php">
          <div class="card">
          <center><div class="card" style="height:50%; width:50%; border:none; margin-top:5%;;"><img src="../../images/view.png" class="card-img-top" alt="Card image cap"></div></center>
            <div class="card-body">
              <h4>View Status</h4>
              <p>Track the progress of facility failures you have reported here!</p>
            </div>
          </div>
          </a>
        </div>

      </div>
    </div>
  </div><!--End Row-->


    
    </div><!--End content-wrapper-->
 
  </div><!--End wrapper-->

</body>
</html>
